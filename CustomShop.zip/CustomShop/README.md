# CustomShop 1.1.0 – /shop /ah /sell /orders

Yêu cầu server: Paper/Spigot 1.21.x + **Vault** + một plugin tiền (vd EssentialsX).

## Build bằng GitHub (không cần máy tính)
1. Tạo repo mới, upload toàn bộ thư mục này (nhớ có cả `.github/workflows/build.yml`).
2. Vào tab **Actions** → chạy "Build plugin" → tải artifact **CustomShop** → lấy `CustomShop.jar`.
3. Bỏ vào `plugins/`, restart server.

> Nâng cấp từ 1.0.0: giữ nguyên `auctions.yml` và `orders.yml`. Xóa `config.yml` cũ (hoặc copy mục `safety:` và `gui:` mới vào) để có các tùy chọn an toàn. `shop.yml` mới đã bỏ trùng lặp, bố cục lại slot; nếu bạn đã sửa giá thì chỉ cần đổi `slot:` các danh mục thành 19 21 23 25 / 28 30 32 34.

## Lệnh
- `/shop` – menu danh mục (sửa giá trong `plugins/CustomShop/shop.yml`)
- `/shop reload` – nạp lại config + quét lại giá · `/shop audit` – xem các mức giá có thể bị lợi dụng (admin)
- `/sell` – thả đồ vào để bán · `/sell hand` · `/sell all`
- `/ah` – chợ người chơi · `/ah sell <giá>` (cầm đồ trên tay, hỗ trợ 1.5k/2m) · `/ah <tên đồ>` để tìm
- `/orders` – đơn hàng · `/orders create <số lượng> <giá/cái> [vật phẩm]` · `/orders my`

## Có gì mới ở 1.1.0
- **Giao diện mới**: khung viền + góc màu, đầu người chơi hiện số dư, lưới 7x4 gọn gàng, âm thanh khi bấm/mua/bán, màu hex (`&#RRGGBB`), màn chọn số lượng đổi ngay trong menu (±1 / ±16 / ±64, đặt 1, đặt 1 stack), nút Mua / Bán / Bán tất cả. Đổi màu khung ở mục `gui:` trong `config.yml`.
- **Không có spawner**: spawner bị chặn cứng trong code (không shop, không bán, không `/ah`, không `/orders`).
- **Chống lỗi mua→bán ra tiền**: xem `AUDIT.md`.

## Ghi chú
- Thuế /ah, thời gian hết hạn, giới hạn đăng bán/đơn hàng: `config.yml`
- Dữ liệu lưu ở `auctions.yml` và `orders.yml`, được ghi **ngay** khi có thay đổi (an toàn khi server bị sập).
- Chỉ đồ "thường" (không đổi tên/enchant/hư) bán được vào shop và giao được cho đơn hàng.
- Nếu trùng lệnh với EssentialsX (`/sell`...), plugin này được load trước nên sẽ ưu tiên.
- Muốn bản API khác: sửa `paper-api` version trong `pom.xml`.
