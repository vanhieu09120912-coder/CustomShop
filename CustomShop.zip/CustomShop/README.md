# CustomShop – /shop /ah /sell /orders

Yêu cầu server: Paper/Spigot 1.21.x + **Vault** + một plugin tiền (vd EssentialsX).

## Build bằng GitHub (không cần máy tính)
1. Tạo repo mới, upload toàn bộ thư mục này (nhớ có cả `.github/workflows/build.yml`).
2. Vào tab **Actions** → chạy "Build plugin" → tải artifact **CustomShop** → lấy `CustomShop.jar`.
3. Bỏ vào `plugins/`, restart server.

## Lệnh
- `/shop` – menu danh mục (sửa giá trong `plugins/CustomShop/shop.yml`), `/shop reload` (admin)
- `/sell` – thả đồ vào để bán · `/sell hand` · `/sell all`
- `/ah` – chợ người chơi · `/ah sell <giá>` (cầm đồ trên tay, hỗ trợ 1.5k/2m) · `/ah <tên đồ>` để tìm
  - nút **ITEM CỦA BẠN**: thu hồi đồ đang bán / đã hết hạn
- `/orders` – đơn hàng · `/orders create <số lượng> <giá/cái> [vật phẩm]` · `/orders my`
  - nút **ĐƠN HÀNG CỦA BẠN**: chuột trái nhận hàng, chuột phải hủy đơn (hoàn tiền)

## Ghi chú
- Thuế /ah, thời gian hết hạn, giới hạn đăng bán/đơn hàng: `config.yml`
- Dữ liệu lưu ở `auctions.yml` và `orders.yml` trong thư mục plugin.
- Chỉ đồ "thường" (không đổi tên/enchant) bán được vào shop và giao được cho đơn hàng.
- Nếu trùng lệnh với EssentialsX (`/sell`...), plugin này được load trước nên sẽ ưu tiên.
- Muốn bản API khác: sửa `paper-api` version trong `pom.xml`.
