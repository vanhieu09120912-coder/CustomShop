# Báo cáo rà soát lỗ hổng mua / bán / tiền

Phạm vi: mã nguồn CustomShop 1.0.0 (đọc toàn bộ) và EconomyShopGUI 7.3.4 (chỉ đọc `config.yml`, file ngôn ngữ và bảng giá mặc định; plugin này chỉ có bản đã biên dịch nên mình không đọc logic mua/bán bên trong của nó).

## A. Lỗi / rủi ro tìm thấy trong CustomShop 1.0.0 và cách đã sửa

| # | Vấn đề | Mức | Đã sửa |
|---|--------|-----|--------|
| 1 | **Dupe khi server sập**: dữ liệu `/ah` và `/orders` chỉ lưu mỗi 5 giây. Mua xong mà sập trước lúc lưu → khởi động lại, listing vẫn còn → mua lại lần nữa (người bán nhận tiền 2 lần / đồ nhân đôi). Tương tự: nhận hàng đơn, hủy đơn nhận hoàn tiền 2 lần. | Cao | Ghi file **ngay** sau mỗi thay đổi (ghi file tạm rồi đổi tên nguyên tử). Thứ tự luôn là "xóa listing / ghi nhận + lưu" trước, "trả tiền / đưa đồ" sau → nếu sập thì chỉ mất đồ, không bao giờ nhân đôi. |
| 2 | **Thuế `/ah` không giới hạn**: `tax-percent` âm → người bán nhận nhiều hơn giá mua (in tiền); >100 → trừ tiền người bán. | Cao (nếu config sai) | Ép về 0–100. |
| 3 | **Không kiểm tra cộng/trừ tiền thành công**: `deposit` bỏ qua kết quả. Plugin tiền từ chối (đạt trần số dư…) thì đồ mất mà không có tiền; hoặc người bán không nhận tiền nhưng người mua vẫn có đồ. | Trung bình | `deposit/withdraw` trả về thành công/thất bại; mọi luồng (sell, /sell, /ah, /orders) đều hoàn tác: trả đồ, hoàn tiền, khôi phục listing/đơn. |
| 4 | **Giá quá nhỏ làm tròn về 0**: giá mua `0.001` → `round()` = 0 → mua miễn phí. | Trung bình (config) | Giá < `$0.01` bị tắt; chi phí giao dịch phải ≥ `$0.01`. |
| 5 | **Bán lời nhờ craft/nung**: shop mua nguyên liệu rẻ, craft/nung ra món có giá bán cao hơn. Không có kiểm tra nào. | Cao (khi chỉnh giá) | `PriceGuard`: dựa vào công thức thật của server (craft, nung, stonecutter, smithing, nhiều bước), tính chi phí rẻ nhất để có mỗi món, nếu giá bán > chi phí × `max-sell-ratio` (mặc định 0.5) thì tự hạ giá bán. Chạy lúc bật và khi `/shop reload`; xem bằng `/shop audit`. |
| 6 | **Bán > mua** trong cùng một món hoặc món khai báo 2 lần (REDSTONE nằm ở 2 danh mục) → có thể dùng giá mua của dòng này, giá bán của dòng kia. | Trung bình (config) | Mỗi vật phẩm chỉ nhận 1 dòng (dòng đầu); giá bán bị giới hạn ≤ giá mua × tỉ lệ. |
| 7 | **Creative**: người chơi Creative lấy vật phẩm vô hạn rồi bán/đăng `/ah`/giao hàng. | Cao | Chặn mọi giao dịch khi Creative (trừ có `customshop.admin`); có thể tắt shop theo world (`safety.disabled-worlds`). |
| 8 | **Đăng/đặt vật phẩm cấm**: `/ah sell` và `/orders create` nhận cả spawner, bedrock, command block… | Trung bình | Spawner chặn cứng; thêm `safety.blacklist` trong config. |
| 9 | **Spam click / auto-click** lên nút mua/bán/xác nhận. | Thấp | Giới hạn `click-delay-ms` (mặc định 120ms) giữa hai lần bấm nút. |
| 10 | **`parseMoney`** nhận cả dạng hex (`0x1p3`) và số mũ (`1e5`), dễ nhập nhầm ra giá lạ. | Thấp | Chỉ nhận số thập phân thường (kèm k/m/b/t); mọi nơi gọi đều yêu cầu giá > 0. |
| 11 | Mua ở shop: phần đồ không nhét vừa túi bị mất mà vẫn bị trừ tiền. | Thấp | Hoàn tiền phần không nhận được. |

Đã kiểm tra và **không** thấy lỗ hổng: tự mua đồ của mình ở `/ah`, tự giao hàng cho đơn của mình, hai người cùng giao cho một đơn (số lượng tính lúc đóng menu), hủy đơn 2 lần, click shift/số/double-click/kéo thả vào menu bán (ô điều khiển đều bị khóa).

## B. EconomyShopGUI 7.3.4 (tham khảo)

- Bảng giá mặc định (724 mục trong 16 danh mục): **không có** món nào bán ≥ mua khi cả hai đều bật; 9 món "sell ≥ buy" thực chất là món chỉ-bán (buy = -1) như đầu mob, nên không phải lỗi.
- Mục `Spawners` có 18 spawner (giá mua 15.000 – 1.000.000, không bán lại). Đây là mục đã bỏ trong bản này.
- Các cài đặt trong `config.yml` có thể mở lỗ hổng nếu bật sai: `match-item-meta: false` (bán đồ bất kể tên/enchant/loại spawner theo giá gốc), `allow-illegal-stacks: true`, `sort-items-by: DESCENDING_SELL_PRICE` khi có món trùng với giá khác nhau (luôn bán theo giá cao nhất). Nếu tiếp tục dùng EconomyShopGUI, nên kiểm tra các mục này.

## C. Giới hạn của việc kiểm tra

- Bản này được biên dịch thử với bộ stub API Bukkit/Vault tự viết (không tải được Paper API trong môi trường làm việc) và các hàm xử lý tiền đã chạy thử; **chưa được chạy trên server Paper thật**. Hãy build bằng GitHub Actions và thử trên server test trước (mua, bán, `/sell`, `/ah sell`, `/orders create` + giao hàng, `/shop audit`).
- `PriceGuard` bỏ qua các món cần nguyên liệu không có trong shop (không biết giá) và không tính vật phẩm trả lại khi craft (thùng sắt, chai…), nên chỉ phát hiện lời ở những chuỗi toàn nguyên liệu có giá trong shop.
