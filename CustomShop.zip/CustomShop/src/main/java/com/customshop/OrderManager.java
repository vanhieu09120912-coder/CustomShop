package com.customshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Đơn hàng: người đặt trả trước (amount x price), người khác giao đúng vật phẩm để nhận tiền.
 * Hàng đã giao nằm chờ người đặt vào "ĐƠN HÀNG CỦA BẠN" để nhận.
 */
public class OrderManager {
    public static class Order {
        public long id;
        public UUID owner;
        public String ownerName;
        public Material type;
        public int amount, delivered, collected;
        public double price; // giá mỗi cái
        public long created;

        public int remaining() {
            return amount - delivered;
        }
    }

    private final CustomShop plugin;
    private final File file;
    private final Map<Long, Order> orders = new LinkedHashMap<>();
    private long nextId = 1;
    private boolean dirty;

    public OrderManager(CustomShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "orders.yml");
    }

    public void load() {
        orders.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection root = y.getConfigurationSection("orders");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(key);
            if (c == null) continue;
            try {
                Order o = new Order();
                o.id = Long.parseLong(key);
                o.owner = UUID.fromString(c.getString("owner", ""));
                o.ownerName = c.getString("name", "?");
                Material m = Material.matchMaterial(c.getString("type", ""));
                if (m == null) continue;
                o.type = m;
                o.amount = c.getInt("amount");
                o.delivered = c.getInt("delivered");
                o.collected = c.getInt("collected");
                o.price = c.getDouble("price");
                o.created = c.getLong("created");
                orders.put(o.id, o);
                nextId = Math.max(nextId, o.id + 1);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Bỏ qua đơn hàng lỗi: " + key);
            }
        }
    }

    public void save() {
        dirty = false;
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Order o : orders.values()) {
            String p = "orders." + o.id + ".";
            y.set(p + "owner", o.owner.toString());
            y.set(p + "name", o.ownerName);
            y.set(p + "type", o.type.name());
            y.set(p + "amount", o.amount);
            y.set(p + "delivered", o.delivered);
            y.set(p + "collected", o.collected);
            y.set(p + "price", o.price);
            y.set(p + "created", o.created);
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            dirty = true;
            plugin.getLogger().severe("Không lưu được orders.yml: " + ex.getMessage());
        }
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    // ---------- Truy vấn ----------
    public Order get(long id) {
        return orders.get(id);
    }

    /** Các đơn còn thiếu hàng. */
    public List<Order> browse(Sort sort) {
        List<Order> out = new ArrayList<>();
        for (Order o : orders.values()) if (o.remaining() > 0) out.add(o);
        switch (sort) {
            case NEWEST -> out.sort((a, b) -> Long.compare(b.created, a.created));
            case PRICE_ASC -> out.sort((a, b) -> Double.compare(a.price, b.price));
            case PRICE_DESC -> out.sort((a, b) -> Double.compare(b.price, a.price));
        }
        return out;
    }

    public List<Order> of(UUID uuid) {
        List<Order> out = new ArrayList<>();
        for (Order o : orders.values()) if (o.owner.equals(uuid)) out.add(o);
        out.sort((a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    // ---------- Hành động (trả về lỗi dạng text, null = thành công) ----------
    public String create(Player p, Material mat, int amount, double price) {
        FileConfiguration c = plugin.getConfig();
        if (mat == null || mat.isAir() || !mat.isItem()) {
            return "&cVật phẩm không hợp lệ (cầm vật phẩm trên tay hoặc ghi tên vật phẩm).";
        }
        int maxAmount = c.getInt("orders.max-amount", 10000);
        if (amount < 1 || amount > maxAmount) return "&cSố lượng phải từ 1 đến " + maxAmount + ".";
        price = Util.round(price);
        double minP = c.getDouble("orders.min-price", 0.01);
        double maxP = c.getDouble("orders.max-price", 1_000_000_000d);
        if (price < minP) return "&cGiá mỗi cái tối thiểu là " + Util.money(minP) + ".";
        if (price > maxP) return "&cGiá mỗi cái tối đa là " + Util.money(maxP) + ".";
        int limit = c.getInt("orders.max-per-player", 5);
        int mine = 0;
        for (Order o : orders.values()) if (o.owner.equals(p.getUniqueId())) mine++;
        if (mine >= limit) return "&cBạn chỉ được có tối đa " + limit + " đơn hàng.";

        double total = Util.round(price * amount);
        if (!plugin.withdraw(p, total)) return "&cBạn không đủ tiền, cần " + Util.money(total) + ".";

        Order o = new Order();
        o.id = nextId++;
        o.owner = p.getUniqueId();
        o.ownerName = p.getName();
        o.type = mat;
        o.amount = amount;
        o.price = price;
        o.created = System.currentTimeMillis();
        orders.put(o.id, o);
        dirty = true;
        Util.msg(p, "&aĐã tạo đơn hàng &f" + amount + "x " + Util.pretty(mat) + " &a- &f" + Util.money(price) + "/cái &a(đã trừ &f" + Util.money(total) + "&a).");
        return null;
    }

    /** Người giao hàng: đã được lấy đúng số item ra khỏi menu, ở đây chỉ ghi nhận và trả tiền. */
    public void deliver(Player p, Order o, int count) {
        if (count <= 0) return;
        o.delivered += count;
        dirty = true;
        double pay = Util.round(count * o.price);
        plugin.deposit(p, pay);
        Util.msg(p, "&aĐã giao &f" + count + "x " + Util.pretty(o.type) + " &a, nhận được &f" + Util.money(pay) + "&a.");
        Player owner = Bukkit.getPlayer(o.owner);
        if (owner != null) {
            Util.msg(owner, "&e" + p.getName() + " &7đã giao &f" + count + "x " + Util.pretty(o.type) + " &7cho đơn hàng của bạn. Vào &f/orders &7→ &fĐƠN HÀNG CỦA BẠN &7để nhận.");
        }
    }

    public String collect(Player p, long id) {
        Order o = orders.get(id);
        if (o == null || !o.owner.equals(p.getUniqueId())) return "&cĐơn hàng không tồn tại.";
        int avail = o.delivered - o.collected;
        if (avail <= 0) return "&cChưa có hàng để nhận.";
        int give = Math.min(avail, Util.room(p.getInventory(), o.type));
        if (give <= 0) return "&cTúi đồ của bạn đã đầy.";
        p.getInventory().addItem(new ItemStack(o.type, give));
        o.collected += give;
        dirty = true;
        if (o.remaining() == 0 && o.collected >= o.delivered) orders.remove(id);
        Util.msg(p, "&aĐã nhận &f" + give + "x " + Util.pretty(o.type) + "&a.");
        return null;
    }

    public String cancel(Player p, long id) {
        Order o = orders.get(id);
        if (o == null || !o.owner.equals(p.getUniqueId())) return "&cĐơn hàng không tồn tại.";
        int remaining = o.remaining();
        if (remaining <= 0) return "&cĐơn đã hoàn tất, hãy bấm chuột trái để nhận hàng.";
        double refund = Util.round(remaining * o.price);
        plugin.deposit(p, refund);
        o.amount = o.delivered;
        dirty = true;
        if (o.collected >= o.delivered) orders.remove(id);
        Util.msg(p, "&aĐã hủy đơn hàng, hoàn lại &f" + Util.money(refund) + "&a" + (o.delivered > o.collected ? " (hàng đã giao vẫn nhận được)." : "."));
        return null;
    }
}
