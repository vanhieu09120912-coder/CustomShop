package com.customshop;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Nhân vật mang SKIN THẬT của người chơi (entity Mannequin của Minecraft 1.21.9+).
 *
 * Mọi thứ gọi qua reflection nên plugin vẫn biên dịch với API 1.21.4 và vẫn chạy trên server cũ:
 * nếu server không có Mannequin thì {@link #spawn} trả về null và menu tự dùng giá đỡ giáp như trước.
 */
final class SkinFigure {
    private SkinFigure() {}

    private static boolean warned = false;

    /** Tạo nhân vật (ẩn với mọi người, người gọi tự showEntity cho đúng người xem). null = không hỗ trợ. */
    static Entity spawn(CustomShop plugin, Player viewer, Location feet, double scale) {
        try {
            EntityType type = Registry.ENTITY_TYPE.get(NamespacedKey.minecraft("mannequin"));
            if (type == null) return null; // server < 1.21.9
            Class<? extends Entity> cls = type.getEntityClass();
            if (cls == null) return null;

            final Object profile = buildProfile(cls, viewer);
            final float yaw = feet.getYaw();
            Entity e = create(feet.getWorld(), feet, cls, ent -> init(ent, cls, profile, yaw, scale));
            if (profile == null) warn(plugin, "không tạo được profile skin, nhân vật sẽ mang skin mặc định");
            return e;
        } catch (Throwable t) {
            warn(plugin, "không tạo được nhân vật skin (" + t + "), dùng giá đỡ giáp thay thế");
            return null;
        }
    }

    private static <T extends Entity> T create(World w, Location l, Class<T> c, Consumer<? super T> init) {
        return w.spawn(l, c, init);
    }

    private static void warn(CustomShop plugin, String s) {
        if (warned) return;
        warned = true;
        plugin.getLogger().warning("[Menu 3D] " + s);
    }

    private static void init(Entity e, Class<?> cls, Object profile, float yaw, double scale) {
        e.setVisibleByDefault(false); // chỉ người mở menu thấy
        e.setPersistent(false);
        e.setGravity(false);
        e.setInvulnerable(true);
        e.setSilent(true);
        e.setCustomNameVisible(false);
        e.setRotation(yaw, 0f);

        if (e instanceof LivingEntity le) {
            le.setCollidable(false);
            try {
                Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft("scale"));
                AttributeInstance ai = a == null ? null : le.getAttribute(a);
                if (ai != null) ai.setBaseValue(Math.max(0.5, Math.min(1.0, scale)));
            } catch (Throwable ignored) {
                // không chỉnh được kích thước: giữ cỡ thường
            }
        }

        // body yaw (Paper) - nếu có thì quay thân cùng hướng với đầu
        try {
            cls.getMethod("setBodyYaw", float.class).invoke(e, yaw);
        } catch (Throwable ignored) {
            try {
                e.getClass().getMethod("setBodyYaw", float.class).invoke(e, yaw);
            } catch (Throwable ignored2) {
                // không sao
            }
        }

        call(cls, e, "setImmovable", boolean.class, true);
        try {
            // null = ẩn dòng mô tả "NPC" mặc định phía trên đầu
            for (Method m : cls.getMethods()) {
                if (m.getName().equals("setDescription") && m.getParameterCount() == 1) {
                    m.invoke(e, new Object[]{null});
                    break;
                }
            }
        } catch (Throwable ignored) {
            // không sao
        }

        if (profile != null) {
            try {
                for (Method m : cls.getMethods()) {
                    if (m.getName().equals("setProfile") && m.getParameterCount() == 1
                            && m.getParameterTypes()[0].isInstance(profile)) {
                        m.invoke(e, profile);
                        break;
                    }
                }
            } catch (Throwable t) {
                throw new IllegalStateException("setProfile: " + t, t);
            }
        }
    }

    private static void call(Class<?> cls, Object target, String name, Class<?> param, Object arg) {
        try {
            cls.getMethod(name, param).invoke(target, arg);
        } catch (Throwable ignored) {
            // không sao
        }
    }

    // ---------------------------------------------------------------------
    // Profile skin
    // ---------------------------------------------------------------------
    /** Dựng đối tượng profile đúng kiểu mà Mannequin#setProfile đang nhận (ResolvableProfile hoặc PlayerProfile). */
    private static Object buildProfile(Class<?> mannequin, Player viewer) throws Exception {
        Method setter = null;
        for (Method m : mannequin.getMethods()) {
            if (m.getName().equals("setProfile") && m.getParameterCount() == 1) {
                // ưu tiên kiểu ResolvableProfile
                if (setter == null || m.getParameterTypes()[0].getSimpleName().equals("ResolvableProfile")) setter = m;
            }
        }
        if (setter == null) return null;

        Object player = viewer.getPlayerProfile(); // có sẵn textures nếu người chơi có skin
        Class<?> want = setter.getParameterTypes()[0];
        if (want.isInstance(player)) return player;
        if (!want.getSimpleName().equals("ResolvableProfile")) return null;

        // 1) ResolvableProfile.resolvableProfile(PlayerProfile)
        for (Method m : want.getMethods()) {
            if (Modifier.isStatic(m.getModifiers()) && m.getName().equals("resolvableProfile")
                    && m.getParameterCount() == 1 && m.getParameterTypes()[0].isInstance(player)) {
                return m.invoke(null, player);
            }
        }

        // 2) ResolvableProfile.resolvableProfile().uuid().name().addProperties().build()
        Class<?> builderType = Class.forName(want.getName() + "$Builder");
        Object builder = want.getMethod("resolvableProfile").invoke(null);
        UUID id = viewer.getUniqueId();
        String name = viewer.getName();
        Collection<?> props = null;
        try {
            Method gp = findGetter(player, "getProperties");
            if (gp != null) props = (Collection<?>) gp.invoke(player);
        } catch (Throwable ignored) {
            // không có properties: Minecraft sẽ tự tra skin theo uuid/tên
        }
        builder = builderType.getMethod("uuid", UUID.class).invoke(builder, id);
        builder = builderType.getMethod("name", String.class).invoke(builder, name);
        if (props != null && !props.isEmpty()) {
            for (Method m : builderType.getMethods()) {
                if (m.getName().equals("addProperties") && m.getParameterCount() == 1) {
                    builder = m.invoke(builder, props);
                    break;
                }
            }
        }
        return builderType.getMethod("build").invoke(builder);
    }

    /** Tìm getter trên interface công khai (class cài đặt của CraftBukkit có thể không truy cập được). */
    private static Method findGetter(Object o, String name) {
        for (Class<?> c : o.getClass().getInterfaces()) {
            try {
                return c.getMethod(name);
            } catch (NoSuchMethodException ignored) {
                // thử interface kế tiếp
            }
        }
        try {
            return o.getClass().getMethod(name);
        } catch (NoSuchMethodException e) {
            return null;
        }
    }
}
