package com.customshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** /huongdan - menu hướng dẫn 3D (nội dung trong huongdan.yml). */
public class GuideManager implements Listener {
    public static class Button {
        public String id;
        public String label;
        public Material icon = Material.BOOK;
        public String command;
        public String leftTitle = "";
        public String rightTitle = "";
        public final List<String> left = new ArrayList<>();
        public final List<String> right = new ArrayList<>();

        /** true = bấm để xem trang nội dung; false = bấm để chạy lệnh. */
        public boolean isPage() {
            return command == null || command.isEmpty();
        }
    }

    private final CustomShop plugin;
    private final List<Button> buttons = new ArrayList<>();
    private final Map<UUID, GuideSession> sessions = new HashMap<>();

    private String title = "&d&lMENU &8/ &fHƯỚNG DẪN";
    private String hint = "&7Nhìn vào nút &8& &7bấm chuột để chọn &8· &7Shift để đóng";
    private String defaultId = "";
    private double distance = 3.2;
    private double textScale = 0.5;
    private double maxDistance = 7.0;
    private Material panel = Material.BLACK_CONCRETE;
    private Material accent = Material.RED_CONCRETE;

    public GuideManager(CustomShop plugin) {
        this.plugin = plugin;
    }

    public CustomShop plugin() { return plugin; }
    public List<Button> buttons() { return buttons; }
    public String title() { return title; }
    public String hint() { return hint; }
    public double distance() { return distance; }
    public double textScale() { return textScale; }
    public double maxDistance() { return maxDistance; }
    public Material panelMaterial() { return panel; }
    public Material accentMaterial() { return accent; }

    public int defaultIndex() {
        for (int i = 0; i < buttons.size(); i++) {
            Button b = buttons.get(i);
            if (b.isPage() && b.id.equalsIgnoreCase(defaultId)) return i;
        }
        for (int i = 0; i < buttons.size(); i++) if (buttons.get(i).isPage()) return i;
        return 0;
    }

    private static Material mat(String name, Material def) {
        if (name == null) return def;
        Material m = Material.matchMaterial(name);
        return (m != null && m.isBlock()) ? m : def;
    }

    public void load() {
        closeAll();
        buttons.clear();
        File f = new File(plugin.getDataFolder(), "huongdan.yml");
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        title = y.getString("title", title);
        hint = y.getString("hint", hint);
        defaultId = y.getString("default", "");
        distance = Math.max(1.5, Math.min(8, y.getDouble("distance", 3.2)));
        textScale = Math.max(0.2, Math.min(2, y.getDouble("text-scale", 0.5)));
        maxDistance = Math.max(3, Math.min(20, y.getDouble("max-distance", 7.0)));
        panel = mat(y.getString("panel-block"), Material.BLACK_CONCRETE);
        accent = mat(y.getString("accent-block"), Material.RED_CONCRETE);

        ConfigurationSection root = y.getConfigurationSection("buttons");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Button b = new Button();
            b.id = id;
            b.label = s.getString("label", id);
            Material ic = Material.matchMaterial(s.getString("icon", "BOOK"));
            if (ic != null && ic.isItem()) b.icon = ic;
            b.command = s.getString("command", "");
            b.leftTitle = s.getString("left-title", "");
            b.rightTitle = s.getString("right-title", "");
            b.left.addAll(s.getStringList("left"));
            b.right.addAll(s.getStringList("right"));
            buttons.add(b);
            if (buttons.size() >= 9) break; // tối đa 9 nút cho vừa màn hình
        }
    }

    // ---------------------------------------------------------------------
    public boolean isOpen(Player p) {
        return sessions.containsKey(p.getUniqueId());
    }

    /** /huongdan: mở, gõ lại thì đóng. */
    public void toggle(Player p) {
        if (isOpen(p)) {
            close(p);
            return;
        }
        if (buttons.isEmpty()) {
            Util.msg(p, "&cChưa có nội dung hướng dẫn (huongdan.yml trống).");
            return;
        }
        GuideSession s = new GuideSession(this, p);
        sessions.put(p.getUniqueId(), s);
        try {
            s.open();
            Util.msg(p, "&7Nhìn vào nút và bấm chuột để chọn. Nhấn &fShift &7để đóng.");
        } catch (Throwable t) {
            plugin.getLogger().warning("Không mở được menu 3D: " + t);
            s.remove();
            sessions.remove(p.getUniqueId());
            Util.msg(p, "&cServer không hỗ trợ menu 3D (cần Paper 1.20+).");
        }
    }

    public void close(Player p) {
        GuideSession s = sessions.remove(p.getUniqueId());
        if (s != null) s.remove();
    }

    public void closeAll() {
        for (GuideSession s : new ArrayList<>(sessions.values())) s.remove();
        sessions.clear();
    }

    /** Gọi mỗi 2 tick. */
    public void tick() {
        if (sessions.isEmpty()) return;
        for (GuideSession s : new ArrayList<>(sessions.values())) {
            boolean ok;
            try {
                ok = s.tick();
            } catch (Throwable t) {
                ok = false;
            }
            if (!ok) close(s.viewer());
        }
    }

    // ---------------------------------------------------------------------
    // Sự kiện
    // ---------------------------------------------------------------------
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        GuideSession s = sessions.get(e.getPlayer().getUniqueId());
        if (s == null || e.getAction() == Action.PHYSICAL) return;
        e.setCancelled(true);
        s.click();
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        GuideSession s = sessions.get(e.getPlayer().getUniqueId());
        if (s != null) s.click();
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (e.isSneaking() && isOpen(e.getPlayer())) close(e.getPlayer());
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (isOpen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        close(e.getPlayer());
    }
}
