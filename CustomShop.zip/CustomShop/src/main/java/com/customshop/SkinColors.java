package com.customshop;

import java.awt.image.BufferedImage;

/**
 * Lấy màu trung bình áo / quần / giày từ ảnh skin (64x64 hoặc 64x32) để nhuộm giáp da
 * cho nhân vật ở giữa menu. Trả về {áo, quần, giày} dạng 0xRRGGBB.
 */
final class SkinColors {
    private SkinColors() {}

    static final int[] DEFAULT = {0x3d6cb0, 0x34495e, 0x2b2b2b};
    /** Giáp da nhuộm sẽ tối hơn màu gốc, nên làm sáng lên một chút cho giống skin. */
    private static final double LIGHTEN = 1.25;

    static int[] compute(BufferedImage img) {
        if (img == null || img.getWidth() < 64 || img.getHeight() < 32) return DEFAULT;
        boolean modern = img.getHeight() >= 64;

        long[] chest = new long[4];
        long[] legs = new long[4];
        long[] boots = new long[4];

        // Thân trước (kèm lớp áo khoác ngoài nếu có)
        sample(img, 20, 20, modern ? 20 : -1, 36, 8, 12, 0, 12, chest);

        // Chân phải; chân trái (skin cũ 64x32 dùng chung với chân phải)
        sample(img, 4, 20, modern ? 4 : -1, 36, 4, 12, 0, 9, legs);
        sample(img, 4, 20, modern ? 4 : -1, 36, 4, 12, 9, 12, boots);
        if (modern) {
            sample(img, 20, 52, 4, 52, 4, 12, 0, 9, legs);
            sample(img, 20, 52, 4, 52, 4, 12, 9, 12, boots);
        }

        return new int[]{avg(chest, DEFAULT[0]), avg(legs, DEFAULT[1]), avg(boots, DEFAULT[2])};
    }

    /** Cộng dồn các điểm ảnh không trong suốt; lớp phủ (nếu có) đè lên lớp gốc. */
    private static void sample(BufferedImage img, int bx, int by, int ox, int oy, int w, int h,
                               int rowFrom, int rowTo, long[] acc) {
        for (int y = rowFrom; y < rowTo; y++) {
            for (int x = 0; x < w; x++) {
                int argb = img.getRGB(bx + x, by + y);
                if (ox >= 0) {
                    int over = img.getRGB(ox + x, oy + y);
                    if ((over >>> 24) >= 128) argb = over;
                }
                if ((argb >>> 24) < 128) continue;
                acc[0] += (argb >> 16) & 0xFF;
                acc[1] += (argb >> 8) & 0xFF;
                acc[2] += argb & 0xFF;
                acc[3]++;
            }
        }
    }

    private static int avg(long[] a, int fallback) {
        if (a[3] == 0) return fallback;
        int r = bright(a[0] / a[3]);
        int g = bright(a[1] / a[3]);
        int b = bright(a[2] / a[3]);
        return (r << 16) | (g << 8) | b;
    }

    private static int bright(long v) {
        return (int) Math.min(255, Math.round(v * LIGHTEN));
    }
}
