package com.customshop;

public enum Sort {
    NEWEST("Mới nhất"),
    PRICE_ASC("Giá thấp → cao"),
    PRICE_DESC("Giá cao → thấp");

    public final String label;

    Sort(String label) {
        this.label = label;
    }

    public Sort next() {
        return values()[(ordinal() + 1) % values().length];
    }
}
