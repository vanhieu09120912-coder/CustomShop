package com.customshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.CookingRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Recipe;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ShapelessRecipe;
import org.bukkit.inventory.SmithingTransformRecipe;
import org.bukkit.inventory.StonecuttingRecipe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Chống lỗi "mua -> craft/nung -> bán ra lời".
 *
 * Với mỗi vật phẩm, tính chi phí rẻ nhất để có được nó bằng tiền trong shop
 * (mua thẳng, hoặc mua nguyên liệu rồi craft / nung / stonecutter / smithing, lặp nhiều bước).
 * Nếu giá bán lớn hơn chi phí đó x tỉ lệ (safety.max-sell-ratio) thì hạ giá bán xuống.
 */
final class PriceGuard {
    private PriceGuard() {}

    private static final class Rec {
        final Material result;
        final int amount;
        final List<List<Material>> ingredients;

        Rec(Material result, int amount, List<List<Material>> ingredients) {
            this.result = result;
            this.amount = Math.max(1, amount);
            this.ingredients = ingredients;
        }
    }

    static List<String> run(CustomShop plugin, ShopManager sm) {
        List<String> findings = new ArrayList<>();
        double ratio = sm.ratio();
        boolean autoFix = plugin.getConfig().getBoolean("safety.auto-fix-prices", true);

        // chi phí rẻ nhất để có 1 cái vật phẩm bằng tiền shop
        Map<Material, Double> acq = new HashMap<>();
        for (ShopManager.Entry e : sm.entries()) {
            if (e.canBuy()) acq.put(e.mat, e.buy);
        }

        List<Rec> recs = new ArrayList<>();
        Iterator<Recipe> it = Bukkit.recipeIterator();
        int guard = 0;
        while (guard++ < 100_000) {
            Recipe r;
            try {
                if (!it.hasNext()) break;
                r = it.next();
            } catch (Throwable t) {
                continue;
            }
            try {
                Rec rec = parse(r);
                if (rec != null) recs.add(rec);
            } catch (Throwable ignored) {
                // công thức lạ: bỏ qua
            }
        }

        for (int pass = 0; pass < 12; pass++) {
            boolean changed = false;
            for (Rec rc : recs) {
                double cost = 0;
                boolean ok = true;
                for (List<Material> opts : rc.ingredients) {
                    double best = Double.MAX_VALUE;
                    for (Material m : opts) {
                        Double v = acq.get(m);
                        if (v != null && v < best) best = v;
                    }
                    if (best == Double.MAX_VALUE) {
                        ok = false;
                        break;
                    }
                    cost += best;
                }
                if (!ok || rc.ingredients.isEmpty()) continue;
                double unit = cost / rc.amount;
                Double cur = acq.get(rc.result);
                if (cur == null || unit < cur - 1e-9) {
                    acq.put(rc.result, unit);
                    changed = true;
                }
            }
            if (!changed) break;
        }

        for (ShopManager.Entry e : sm.entries()) {
            if (!e.canSell()) continue;
            Double a = acq.get(e.mat);
            if (a == null) continue;
            double cap = Util.round(a * ratio);
            if (e.sell > cap + 1e-9) {
                String line = e.mat.name() + ": bán " + Util.full(e.sell) + " nhưng có thể có được với " + Util.full(Util.round(a))
                        + " (giới hạn bán " + Util.full(cap) + ")";
                if (autoFix) {
                    e.sell = cap >= ShopManager.MIN_PRICE ? cap : -1;
                    line += " -> đã hạ giá bán.";
                } else {
                    line += " -> CHƯA sửa (auto-fix-prices đang tắt).";
                }
                findings.add(line);
            }
        }
        return findings;
    }

    private static Rec parse(Recipe r) {
        if (r == null) return null;
        ItemStack res = r.getResult();
        if (res == null || res.getType().isAir()) return null;
        List<List<Material>> ing = new ArrayList<>();
        if (r instanceof ShapedRecipe sr) {
            Map<Character, RecipeChoice> map = sr.getChoiceMap();
            for (String row : sr.getShape()) {
                for (char ch : row.toCharArray()) {
                    RecipeChoice c = map.get(ch);
                    if (c != null) ing.add(options(c));
                }
            }
        } else if (r instanceof ShapelessRecipe sl) {
            for (RecipeChoice c : sl.getChoiceList()) ing.add(options(c));
        } else if (r instanceof CookingRecipe<?> cr) {
            ing.add(options(cr.getInputChoice()));
        } else if (r instanceof StonecuttingRecipe sc) {
            ing.add(options(sc.getInputChoice()));
        } else if (r instanceof SmithingTransformRecipe st) {
            ing.add(options(st.getTemplate()));
            ing.add(options(st.getBase()));
            ing.add(options(st.getAddition()));
        } else {
            return null;
        }
        return new Rec(res.getType(), res.getAmount(), ing);
    }

    private static List<Material> options(RecipeChoice c) {
        List<Material> out = new ArrayList<>();
        if (c == null) return out;
        if (c instanceof RecipeChoice.MaterialChoice mc) {
            out.addAll(mc.getChoices());
        } else if (c instanceof RecipeChoice.ExactChoice ec) {
            for (ItemStack s : ec.getChoices()) out.add(s.getType());
        } else {
            ItemStack s = c.getItemStack();
            if (s != null) out.add(s.getType());
        }
        return out;
    }
}
