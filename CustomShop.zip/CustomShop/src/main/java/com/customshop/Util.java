package com.customshop;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Util {
    private Util() {}

    private static final Pattern HEX = Pattern.compile("&#([0-9a-fA-F]{6})");

    /** Màu &a &l ... và cả màu hex dạng &#RRGGBB. */
    public static String col(String s) {
        if (s == null) return "";
        Matcher m = HEX.matcher(s);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            StringBuilder r = new StringBuilder();
            r.append(ChatColor.COLOR_CHAR).append('x');
            for (char c : m.group(1).toCharArray()) r.append(ChatColor.COLOR_CHAR).append(c);
            m.appendReplacement(sb, Matcher.quoteReplacement(r.toString()));
        }
        m.appendTail(sb);
        return ChatColor.translateAlternateColorCodes('&', sb.toString());
    }

    /** Thêm &r ở đầu để tên/lore không bị in nghiêng. */
    private static String reset(String s) {
        return ChatColor.RESET + col(s);
    }

    public static void msg(CommandSender to, String s) {
        to.sendMessage(col(CustomShop.get().prefix() + s));
    }

    // ---------- Item ----------
    public static ItemStack item(Material m, String name, String... lore) {
        return item(m, 1, name, Arrays.asList(lore));
    }

    public static ItemStack item(Material m, int amount, String name, String... lore) {
        return item(m, amount, name, Arrays.asList(lore));
    }

    public static ItemStack item(Material m, int amount, String name, List<String> lore) {
        ItemStack it = new ItemStack(m, Math.max(1, Math.min(amount, m.getMaxStackSize())));
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        meta.setDisplayName(reset(name));
        if (lore != null && !lore.isEmpty()) {
            List<String> l = new ArrayList<>();
            for (String s : lore) l.add(reset(s));
            meta.setLore(l);
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    /** Đầu người chơi (dùng để hiện số dư). */
    public static ItemStack head(OfflinePlayer owner, String name, String... lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        if (meta instanceof SkullMeta sm) sm.setOwningPlayer(owner);
        meta.setDisplayName(reset(name));
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add(reset(s));
        meta.setLore(l);
        it.setItemMeta(meta);
        return it;
    }

    /** Bản sao của item với lore thêm vào cuối (giữ lore cũ). Chỉ dùng để hiển thị. */
    public static ItemStack addLore(ItemStack base, String... extra) {
        ItemStack it = base.clone();
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;
        List<String> lore = (meta.hasLore() && meta.getLore() != null) ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        for (String s : extra) lore.add(reset(s));
        meta.setLore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    // ---------- Tiền ----------
    public static double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    public static boolean validMoney(double v) {
        return !Double.isNaN(v) && !Double.isInfinite(v);
    }

    /** Dạng rút gọn: $1.2K, $3.5M */
    public static String money(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1_000_000_000_000d) s = trim(v / 1_000_000_000_000d) + "T";
        else if (a >= 1_000_000_000d) s = trim(v / 1_000_000_000d) + "B";
        else if (a >= 1_000_000d) s = trim(v / 1_000_000d) + "M";
        else if (a >= 1_000d) s = trim(v / 1_000d) + "K";
        else s = trim(v);
        return "$" + s;
    }

    /** Dạng đầy đủ: $1,234.50 */
    public static String full(double v) {
        String s = String.format(Locale.US, "%,.2f", v);
        if (s.endsWith(".00")) s = s.substring(0, s.length() - 3);
        return "$" + s;
    }

    private static String trim(double v) {
        String s = String.format(Locale.US, "%.2f", v);
        if (s.contains(".")) {
            s = s.replaceAll("0+$", "");
            s = s.replaceAll("\\.$", "");
        }
        return s;
    }

    /** Đọc số tiền: 1000, 1.5k, 2m, 3b. Lỗi trả về -1. */
    public static double parseMoney(String in) {
        if (in == null) return -1;
        String s = in.trim().toLowerCase(Locale.ROOT).replace(",", "").replace("$", "");
        if (s.isEmpty()) return -1;
        double mult = 1;
        if (s.endsWith("k")) { mult = 1_000d; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("m")) { mult = 1_000_000d; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("b")) { mult = 1_000_000_000d; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("t")) { mult = 1_000_000_000_000d; s = s.substring(0, s.length() - 1); }
        // chỉ nhận số thập phân thường (chặn dạng hex / mũ lạ)
        if (!s.matches("-?\\d+(\\.\\d+)?")) return -1;
        try {
            double v = Double.parseDouble(s) * mult;
            return validMoney(v) ? v : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static String pretty(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String w : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    public static String duration(long ms) {
        if (ms <= 0) return "0p";
        long m = ms / 60000L;
        long h = m / 60;
        m %= 60;
        long d = h / 24;
        h %= 24;
        if (d > 0) return d + "n " + h + "g";
        if (h > 0) return h + "g " + m + "p";
        return Math.max(1, m) + "p";
    }

    // ---------- Túi đồ ----------
    /** Đếm item "thường" (không có meta) của một loại. */
    public static int count(Inventory inv, Material m) {
        int n = 0;
        for (ItemStack it : inv.getStorageContents()) {
            if (it != null && it.getType() == m && !it.hasItemMeta()) n += it.getAmount();
        }
        return n;
    }

    public static int remove(Inventory inv, Material m, int amount) {
        int left = amount;
        ItemStack[] c = inv.getStorageContents();
        for (int i = 0; i < c.length && left > 0; i++) {
            ItemStack it = c[i];
            if (it == null || it.getType() != m || it.hasItemMeta()) continue;
            int take = Math.min(left, it.getAmount());
            if (take == it.getAmount()) c[i] = null;
            else it.setAmount(it.getAmount() - take);
            left -= take;
        }
        inv.setStorageContents(c);
        return amount - left;
    }

    /** Còn chỗ chứa bao nhiêu item thường của loại này. */
    public static int room(Inventory inv, Material m) {
        int max = m.getMaxStackSize();
        int space = 0;
        for (ItemStack it : inv.getStorageContents()) {
            if (it == null || it.getType().isAir()) space += max;
            else if (it.getType() == m && !it.hasItemMeta()) space += Math.max(0, max - it.getAmount());
        }
        return space;
    }

    public static boolean canFit(Inventory inv, ItemStack stack, int amount) {
        int max = stack.getMaxStackSize();
        int space = 0;
        for (ItemStack it : inv.getStorageContents()) {
            if (it == null || it.getType().isAir()) space += max;
            else if (it.isSimilar(stack)) space += Math.max(0, max - it.getAmount());
            if (space >= amount) return true;
        }
        return space >= amount;
    }

    /** Đưa item cho người chơi; thừa thì rơi xuống chân. */
    public static void give(Player p, ItemStack item) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(item);
        for (ItemStack it : left.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), it);
        }
    }
}
