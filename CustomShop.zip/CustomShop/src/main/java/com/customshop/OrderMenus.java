package com.customshop;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class OrderMenus {
    private OrderMenus() {}

    // =====================================================================
    // /orders - danh sách đơn đang cần hàng
    // =====================================================================
    public static class OrdersMenu extends Menu {
        private int page;
        private int pages = 1;
        private final Sort sort;
        private List<OrderManager.Order> view;

        public OrdersMenu(Player p, int page, Sort sort) {
            super(p);
            this.page = page;
            this.sort = sort;
        }

        @Override
        protected void build() {
            view = CustomShop.get().orders().browse(sort);
            pages = Math.max(1, (view.size() + 44) / 45);
            page = Math.max(0, Math.min(page, pages - 1));
            create(6, "&8đơn hàng (" + (page + 1) + "/" + pages + ")");
            for (int i = 0; i < 45; i++) {
                int idx = page * 45 + i;
                if (idx >= view.size()) break;
                OrderManager.Order o = view.get(idx);
                ItemStack base = new ItemStack(o.type, Math.max(1, Math.min(o.remaining(), o.type.getMaxStackSize())));
                inv.setItem(i, Util.addLore(base,
                        "",
                        "&7Người đặt: &f" + o.ownerName,
                        "&7Đã giao: &f" + o.delivered + "&7/&f" + o.amount,
                        "&7Giá mỗi cái: &a" + Util.money(o.price),
                        "&7Nhận tối đa: &a" + Util.money(Util.round(o.price * o.remaining())),
                        "",
                        "&eBấm để giao hàng"));
            }
            fill(45, 53, filler());
            if (page > 0) inv.setItem(45, Util.item(Material.ARROW, "&eTrang trước"));
            inv.setItem(46, Util.item(Material.HOPPER, "&6Sắp xếp: &f" + sort.label, "&7Bấm để đổi"));
            inv.setItem(47, Util.item(Material.CLOCK, "&bLàm mới"));
            inv.setItem(48, Util.item(Material.OAK_SIGN, "&aTạo đơn hàng",
                    "&7Bấm để xem hướng dẫn", "&f/orders create <số lượng> <giá/cái> [vật phẩm]"));
            inv.setItem(49, Util.item(Material.CHEST, "&a&lĐƠN HÀNG CỦA BẠN", "&7Nhận hàng đã giao / hủy đơn"));
            inv.setItem(50, Util.item(Material.GOLD_INGOT, "&6Chợ người chơi", "&7Mở /ah"));
            inv.setItem(51, Util.item(Material.EMERALD, "&aShop", "&7Mở /shop"));
            if (page < pages - 1) inv.setItem(53, Util.item(Material.ARROW, "&eTrang sau"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s < 45) {
                int idx = page * 45 + s;
                if (idx >= view.size()) return;
                OrderManager.Order o = view.get(idx);
                if (o.owner.equals(player.getUniqueId())) {
                    Util.msg(player, "&eĐây là đơn của bạn. Dùng nút &fĐƠN HÀNG CỦA BẠN &eđể quản lý.");
                    return;
                }
                new DeliverMenu(player, o.id).openLater();
                return;
            }
            switch (s) {
                case 45 -> { if (page > 0) new OrdersMenu(player, page - 1, sort).openLater(); }
                case 46 -> new OrdersMenu(player, 0, sort.next()).openLater();
                case 47 -> new OrdersMenu(player, page, sort).openLater();
                case 48 -> {
                    closeLater();
                    Util.msg(player, "&eTạo đơn: &f/orders create <số lượng> <giá mỗi cái> [vật phẩm]");
                    Util.msg(player, "&7Không ghi vật phẩm = lấy vật phẩm đang cầm trên tay. Ví dụ: &f/orders create 64 10 diamond");
                }
                case 49 -> new MyOrdersMenu(player, 0).openLater();
                case 50 -> new AuctionMenus.AhMenu(player, 0, Sort.NEWEST, null).openLater();
                case 51 -> new ShopMenus.MainMenu(player).openLater();
                case 53 -> { if (page < pages - 1) new OrdersMenu(player, page + 1, sort).openLater(); }
                default -> { }
            }
        }
    }

    // =====================================================================
    // ĐƠN HÀNG CỦA BẠN
    // =====================================================================
    public static class MyOrdersMenu extends Menu {
        private int page;
        private int pages = 1;
        private List<OrderManager.Order> list;

        public MyOrdersMenu(Player p, int page) {
            super(p);
            this.page = page;
        }

        @Override
        protected void build() {
            list = CustomShop.get().orders().of(player.getUniqueId());
            pages = Math.max(1, (list.size() + 44) / 45);
            page = Math.max(0, Math.min(page, pages - 1));
            create(6, "&8Đơn hàng của bạn (" + (page + 1) + "/" + pages + ")");
            for (int i = 0; i < 45; i++) {
                int idx = page * 45 + i;
                if (idx >= list.size()) break;
                OrderManager.Order o = list.get(idx);
                inv.setItem(i, Util.addLore(new ItemStack(o.type),
                        "",
                        "&7Đã giao: &f" + o.delivered + "&7/&f" + o.amount,
                        "&7Chờ nhận: &f" + (o.delivered - o.collected),
                        "&7Giá mỗi cái: &a" + Util.money(o.price),
                        o.remaining() > 0 ? "&7Hoàn tiền nếu hủy: &a" + Util.money(Util.round(o.remaining() * o.price)) : "&aĐã đủ hàng",
                        "",
                        "&eChuột trái: &fNhận hàng",
                        "&eChuột phải: &fHủy đơn (hoàn tiền)"));
            }
            fill(45, 53, filler());
            if (page > 0) inv.setItem(45, Util.item(Material.ARROW, "&eTrang trước"));
            inv.setItem(49, Util.item(Material.BARRIER, "&cQuay lại /orders"));
            if (page < pages - 1) inv.setItem(53, Util.item(Material.ARROW, "&eTrang sau"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s < 45) {
                int idx = page * 45 + s;
                if (idx >= list.size()) return;
                long id = list.get(idx).id;
                OrderManager om = CustomShop.get().orders();
                String err = e.isRightClick() ? om.cancel(player, id) : om.collect(player, id);
                if (err != null) Util.msg(player, err);
                new MyOrdersMenu(player, page).openLater();
                return;
            }
            if (s == 45 && page > 0) new MyOrdersMenu(player, page - 1).openLater();
            else if (s == 49) new OrdersMenu(player, 0, Sort.NEWEST).openLater();
            else if (s == 53 && page < pages - 1) new MyOrdersMenu(player, page + 1).openLater();
        }
    }

    // =====================================================================
    // Giao hàng: thả vật phẩm đúng loại vào, đóng menu / bấm GIAO = nhận tiền
    // =====================================================================
    public static class DeliverMenu extends Menu {
        private final long orderId;
        private boolean cancelled;

        public DeliverMenu(Player p, long orderId) {
            super(p);
            this.orderId = orderId;
        }

        @Override
        public boolean interactive() { return true; }

        @Override
        public boolean isControl(int rawSlot) { return rawSlot >= 45 && rawSlot < 54; }

        @Override
        protected void build() {
            OrderManager.Order o = CustomShop.get().orders().get(orderId);
            create(6, "&8Giao hàng: " + (o == null ? "?" : Util.pretty(o.type)));
            fill(45, 53, filler());
            inv.setItem(45, Util.item(Material.RED_CONCRETE, "&cHủy", "&7Trả lại toàn bộ đồ"));
            inv.setItem(53, Util.item(Material.LIME_CONCRETE, "&a&lGIAO HÀNG", "&7Bấm để giao (đóng menu cũng tự giao)"));
            refresh();
        }

        private int countValid(OrderManager.Order o) {
            int n = 0;
            for (int i = 0; i < 45; i++) {
                ItemStack it = inv.getItem(i);
                if (it != null && it.getType() == o.type && !it.hasItemMeta()) n += it.getAmount();
            }
            return n;
        }

        @Override
        public void refresh() {
            OrderManager.Order o = CustomShop.get().orders().get(orderId);
            if (o == null) return;
            int n = Math.min(countValid(o), o.remaining());
            inv.setItem(49, Util.item(Material.PAPER, "&eThông tin đơn",
                    "&7Còn cần: &f" + o.remaining() + "x " + Util.pretty(o.type),
                    "&7Giá mỗi cái: &a" + Util.money(o.price),
                    "&7Sẽ giao: &f" + n,
                    "&7Nhận: &a" + Util.money(Util.round(o.price * n)),
                    "",
                    "&7Chỉ nhận vật phẩm loại thường",
                    "&7(không đổi tên / enchant)"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s == 45) {
                cancelled = true;
                closeLater();
            } else if (s == 53) {
                closeLater();
            }
        }

        @Override
        public void onClose(InventoryCloseEvent e) {
            CustomShop pl = CustomShop.get();
            OrderManager om = pl.orders();
            OrderManager.Order o = om.get(orderId);
            int need = 0;
            if (!cancelled && o != null && pl.hasEco() && !o.owner.equals(player.getUniqueId())) {
                need = o.remaining();
            }
            int delivered = 0;
            for (int i = 0; i < 45; i++) {
                ItemStack raw = inv.getItem(i);
                if (raw == null || raw.getType().isAir()) continue;
                inv.setItem(i, null);
                ItemStack it = raw.clone();
                if (need > 0 && o != null && it.getType() == o.type && !it.hasItemMeta()) {
                    int take = Math.min(need, it.getAmount());
                    need -= take;
                    delivered += take;
                    if (take < it.getAmount()) {
                        it.setAmount(it.getAmount() - take);
                        Util.give(player, it);
                    }
                } else {
                    Util.give(player, it);
                }
            }
            if (delivered > 0 && o != null) om.deliver(player, o, delivered);
        }
    }
}
