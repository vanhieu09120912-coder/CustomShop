package com.customshop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class CustomShop extends JavaPlugin {
    private static CustomShop instance;
    private Economy economy;
    private String prefix = "&8[&6Shop&8] &7";
    private ShopManager shop;
    private AuctionManager auctions;
    private OrderManager orders;

    public static CustomShop get() { return instance; }
    public String prefix() { return prefix; }
    public ShopManager shop() { return shop; }
    public AuctionManager auctions() { return auctions; }
    public OrderManager orders() { return orders; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        if (!new File(getDataFolder(), "shop.yml").exists()) saveResource("shop.yml", false);
        prefix = getConfig().getString("prefix", prefix);

        shop = new ShopManager(this);
        shop.load();
        auctions = new AuctionManager(this);
        auctions.load();
        orders = new OrderManager(this);
        orders.load();

        getServer().getPluginManager().registerEvents(new MenuListener(), this);

        Commands cmds = new Commands(this);
        for (String n : new String[]{"shop", "ah", "sell", "orders"}) {
            PluginCommand pc = getCommand(n);
            if (pc != null) {
                pc.setExecutor(cmds);
                pc.setTabCompleter(cmds);
            }
        }

        // Hết hạn + lưu dữ liệu (mỗi 5 giây nếu có thay đổi)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            auctions.tick();
            auctions.saveIfDirty();
            orders.saveIfDirty();
        }, 100L, 100L);

        getLogger().info("CustomShop đã bật: /shop /ah /sell /orders");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof Menu) p.closeInventory();
        }
        if (auctions != null) auctions.save();
        if (orders != null) orders.save();
    }

    public void reloadAll() {
        reloadConfig();
        prefix = getConfig().getString("prefix", prefix);
        shop.load();
    }

    // ---------- Kinh tế (Vault) ----------
    public Economy eco() {
        if (economy == null) {
            RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp != null) economy = rsp.getProvider();
        }
        return economy;
    }

    public boolean hasEco() { return eco() != null; }

    public boolean withdraw(OfflinePlayer p, double amount) {
        Economy e = eco();
        if (e == null || amount < 0) return false;
        if (!e.has(p, amount)) return false;
        return e.withdrawPlayer(p, amount).transactionSuccess();
    }

    public void deposit(OfflinePlayer p, double amount) {
        Economy e = eco();
        if (e == null) {
            getLogger().severe("Không có economy, không thể cộng " + amount + " cho " + p.getName());
            return;
        }
        e.depositPlayer(p, amount);
    }
}
