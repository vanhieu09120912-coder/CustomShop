package com.customshop;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class CustomShop extends JavaPlugin {
    private static CustomShop instance;
    private Economy economy;
    private String prefix = "&8[&6Shop&8] &7";
    private ShopManager shop;
    private AuctionManager auctions;
    private OrderManager orders;
    private GuideManager guide;

    private final Set<String> blocked = new HashSet<>();
    private final Set<String> badWorlds = new HashSet<>();
    private boolean blockCreative = true;

    public static CustomShop get() { return instance; }
    public String prefix() { return prefix; }
    public ShopManager shop() { return shop; }
    public AuctionManager auctions() { return auctions; }
    public OrderManager orders() { return orders; }
    public GuideManager guide() { return guide; }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        if (!new File(getDataFolder(), "shop.yml").exists()) saveResource("shop.yml", false);
        if (!new File(getDataFolder(), "huongdan.yml").exists()) saveResource("huongdan.yml", false);
        readSettings();

        shop = new ShopManager(this);
        shop.load();
        auctions = new AuctionManager(this);
        auctions.load();
        orders = new OrderManager(this);
        orders.load();
        guide = new GuideManager(this);
        guide.load();

        getServer().getPluginManager().registerEvents(new MenuListener(), this);
        getServer().getPluginManager().registerEvents(guide, this);

        Commands cmds = new Commands(this);
        for (String n : new String[]{"shop", "ah", "sell", "orders", "huongdan"}) {
            PluginCommand pc = getCommand(n);
            if (pc != null) {
                pc.setExecutor(cmds);
                pc.setTabCompleter(cmds);
            }
        }

        // Quét lỗ hổng giá (mua nguyên liệu -> craft -> bán lời) sau khi server nạp xong công thức
        Bukkit.getScheduler().runTask(this, () -> shop.audit());

        // Hết hạn đăng bán (dữ liệu quan trọng đã được lưu ngay khi có thay đổi)
        Bukkit.getScheduler().runTaskTimer(this, () -> auctions.tick(), 100L, 100L);
        // Menu 3D /huongdan: cập nhật nút đang nhìn mỗi 2 tick
        Bukkit.getScheduler().runTaskTimer(this, () -> guide.tick(), 2L, 2L);

        getLogger().info("CustomShop đã bật: /shop /ah /sell /orders /huongdan");
    }

    @Override
    public void onDisable() {
        if (guide != null) guide.closeAll();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof Menu) p.closeInventory();
        }
        if (auctions != null) auctions.save();
        if (orders != null) orders.save();
    }

    private void readSettings() {
        prefix = getConfig().getString("prefix", prefix);
        blockCreative = getConfig().getBoolean("safety.block-creative", true);
        blocked.clear();
        for (String s : getConfig().getStringList("safety.blacklist")) blocked.add(s.trim().toUpperCase(Locale.ROOT));
        badWorlds.clear();
        for (String s : getConfig().getStringList("safety.disabled-worlds")) badWorlds.add(s.trim().toLowerCase(Locale.ROOT));
    }

    public void reloadAll() {
        reloadConfig();
        readSettings();
        shop.load();
        shop.audit();
        guide.load();
    }

    // ---------- Quy tắc an toàn ----------
    /** Spawner luôn bị chặn hoàn toàn (không bán, không đăng /ah, không đặt đơn). */
    public boolean isBlocked(Material m) {
        if (m == null) return true;
        String n = m.name();
        return n.contains("SPAWNER") || blocked.contains(n);
    }

    /** Trả về lý do không được giao dịch (creative / world bị tắt), null = được phép. */
    public String txError(Player p) {
        if (blockCreative && p.getGameMode() == GameMode.CREATIVE && !p.hasPermission("customshop.admin")) {
            return "&cKhông thể giao dịch khi đang ở chế độ Creative.";
        }
        if (!badWorlds.isEmpty() && badWorlds.contains(p.getWorld().getName().toLowerCase(Locale.ROOT))) {
            return "&cShop bị tắt ở thế giới này.";
        }
        return null;
    }

    // ---------- Kinh tế (Vault) ----------
    public Economy eco() {
        if (economy == null) {
            RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp != null) economy = rsp.getProvider();
        }
        return economy;
    }

    public boolean hasEco() { return eco() != null; }

    public double balance(OfflinePlayer p) {
        Economy e = eco();
        if (e == null) return 0;
        try {
            return e.getBalance(p);
        } catch (Exception ex) {
            return 0;
        }
    }

    /** Trừ tiền. Chỉ nhận số dương hợp lệ; true = đã trừ thành công. */
    public boolean withdraw(OfflinePlayer p, double amount) {
        Economy e = eco();
        if (e == null || !Util.validMoney(amount) || amount <= 0) return false;
        if (!e.has(p, amount)) return false;
        EconomyResponse r = e.withdrawPlayer(p, amount);
        return r != null && r.transactionSuccess();
    }

    /** Cộng tiền. true = đã cộng thành công (0 đồng coi như thành công). */
    public boolean deposit(OfflinePlayer p, double amount) {
        Economy e = eco();
        if (e == null || !Util.validMoney(amount) || amount < 0) return false;
        if (amount == 0) return true;
        EconomyResponse r = e.depositPlayer(p, amount);
        if (r == null || !r.transactionSuccess()) {
            getLogger().severe("Không cộng được " + amount + " cho " + p.getName());
            return false;
        }
        return true;
    }
}
