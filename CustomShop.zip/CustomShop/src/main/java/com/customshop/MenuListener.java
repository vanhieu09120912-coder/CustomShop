package com.customshop;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public class MenuListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Menu m)) return;

        boolean inTop = e.getClickedInventory() == top;

        if (!m.interactive()) {
            e.setCancelled(true);
            if (inTop) m.click(e);
            return;
        }

        // Menu cho phép thả đồ: chỉ khóa các ô điều khiển
        if (e.getAction() == InventoryAction.COLLECT_TO_CURSOR || e.getClick() == ClickType.DOUBLE_CLICK) {
            e.setCancelled(true);
            return;
        }
        if (inTop && m.isControl(e.getRawSlot())) {
            e.setCancelled(true);
            m.click(e);
            return;
        }
        Bukkit.getScheduler().runTask(CustomShop.get(), () -> m.refresh());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof Menu m)) return;
        int size = top.getSize();
        for (int raw : e.getRawSlots()) {
            if (raw < size && (!m.interactive() || m.isControl(raw))) {
                e.setCancelled(true);
                return;
            }
        }
        if (m.interactive()) Bukkit.getScheduler().runTask(CustomShop.get(), () -> m.refresh());
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof Menu m) m.onClose(e);
    }
}
