package com.customshop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Menu GUI cơ bản. Mặc định mọi click đều bị chặn (không lấy được đồ ra). */
public abstract class Menu implements InventoryHolder {
    protected final Player player;
    protected Inventory inv;

    protected Menu(Player player) {
        this.player = player;
    }

    protected void create(int rows, String title) {
        inv = Bukkit.createInventory(this, rows * 9, Util.col(title));
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    /** Tạo inventory (gọi create(...)) và đặt item vào. */
    protected abstract void build();

    /** Xử lý click vào inventory phía trên của menu. */
    public abstract void click(InventoryClickEvent e);

    public void onClose(InventoryCloseEvent e) {}

    /** true = người chơi được thả item vào các ô không phải ô điều khiển (menu bán đồ / giao hàng). */
    public boolean interactive() { return false; }

    public boolean isControl(int rawSlot) { return true; }

    /** Cập nhật thông tin sau mỗi lần click (menu interactive). */
    public void refresh() {}

    public void open() {
        build();
        player.openInventory(inv);
    }

    /** Mở ở tick sau - dùng khi gọi từ trong sự kiện click. */
    public void openLater() {
        Bukkit.getScheduler().runTask(CustomShop.get(), () -> open());
    }

    public void closeLater() {
        Bukkit.getScheduler().runTask(CustomShop.get(), () -> player.closeInventory());
    }
}
