package com.customshop;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ShopMenus {
    private ShopMenus() {}

    // =====================================================================
    // Menu chính /shop
    // =====================================================================
    public static class MainMenu extends Menu {
        public MainMenu(Player p) {
            super(p);
        }

        @Override
        protected void build() {
            CustomShop pl = CustomShop.get();
            ShopManager sm = pl.shop();
            create(6, sm.title());
            Gui.frame(inv);
            inv.setItem(4, Gui.balance(player));

            for (ShopManager.Category c : sm.categories()) {
                if (c.slot < 0 || c.slot > 44) continue;
                List<String> lore = new ArrayList<>();
                lore.addAll(c.lore);
                if (!c.lore.isEmpty()) lore.add("");
                lore.add("&8▪ &7" + c.items.size() + " vật phẩm");
                lore.add("");
                lore.add("&e» Bấm để mở");
                inv.setItem(c.slot, Util.item(c.icon, 1, c.name, lore));
            }

            inv.setItem(46, Util.item(Material.CHEST, "&6&lChợ người chơi",
                    "&7Mua bán với người chơi khác", "&8/ah", "", "&e» Bấm để mở"));
            inv.setItem(48, Util.item(Material.HOPPER, "&a&lBán đồ nhanh",
                    "&7Thả đồ vào để bán lấy tiền", "&8/sell", "", "&e» Bấm để mở"));
            inv.setItem(50, Util.item(Material.WRITABLE_BOOK, "&b&lĐơn hàng",
                    "&7Nhận giao hàng lấy tiền", "&8/orders", "", "&e» Bấm để mở"));
            inv.setItem(52, Util.item(Material.BARRIER, "&c&lĐóng"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            for (ShopManager.Category c : CustomShop.get().shop().categories()) {
                if (c.slot == s) {
                    Gui.click(player);
                    new CategoryMenu(player, c, 0).openLater();
                    return;
                }
            }
            switch (s) {
                case 46 -> { Gui.click(player); new AuctionMenus.AhMenu(player, 0, Sort.NEWEST, null).openLater(); }
                case 48 -> { Gui.click(player); new SellMenu(player).openLater(); }
                case 50 -> { Gui.click(player); new OrderMenus.OrdersMenu(player, 0, Sort.NEWEST).openLater(); }
                case 52 -> closeLater();
                default -> { }
            }
        }
    }

    // =====================================================================
    // Danh mục
    // =====================================================================
    public static class CategoryMenu extends Menu {
        private final ShopManager.Category cat;
        private int page;
        private int pages = 1;

        public CategoryMenu(Player p, ShopManager.Category cat, int page) {
            super(p);
            this.cat = cat;
            this.page = page;
        }

        @Override
        protected void build() {
            List<ShopManager.Entry> items = cat.items;
            pages = Gui.pages(items.size());
            page = Math.max(0, Math.min(page, pages - 1));
            create(6, cat.name + " &8(" + (page + 1) + "/" + pages + ")");
            Gui.frame(inv);

            inv.setItem(4, Util.item(cat.icon, 1, cat.name,
                    "&8▪ &7Trang &f" + (page + 1) + "&7/&f" + pages,
                    "&8▪ &7" + items.size() + " vật phẩm"));

            for (int i = 0; i < Gui.PER_PAGE; i++) {
                int idx = page * Gui.PER_PAGE + i;
                if (idx >= items.size()) break;
                ShopManager.Entry en = items.get(idx);
                inv.setItem(Gui.GRID[i], Util.addLore(new ItemStack(en.mat),
                        "",
                        en.canBuy() ? "&a▎ Mua  &f" + Util.full(en.buy) : "&8▎ Mua  &7Không bán",
                        en.canSell() ? "&c▎ Bán  &f" + Util.full(en.sell) : "&8▎ Bán  &7Không nhận",
                        "",
                        "&e» Bấm để chọn số lượng"));
            }

            if (page > 0) inv.setItem(45, Util.item(Material.ARROW, "&e« Trang trước"));
            inv.setItem(46, Gui.balance(player));
            inv.setItem(49, Util.item(Material.BARRIER, "&c« Quay lại"));
            if (page < pages - 1) inv.setItem(53, Util.item(Material.ARROW, "&eTrang sau »"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            int gi = Gui.gridIndex(s);
            if (gi >= 0) {
                int idx = page * Gui.PER_PAGE + gi;
                if (idx < cat.items.size()) {
                    Gui.click(player);
                    new DetailMenu(player, cat, cat.items.get(idx), page).openLater();
                }
                return;
            }
            if (s == 45 && page > 0) { Gui.click(player); new CategoryMenu(player, cat, page - 1).openLater(); }
            else if (s == 49) { Gui.click(player); new MainMenu(player).openLater(); }
            else if (s == 53 && page < pages - 1) { Gui.click(player); new CategoryMenu(player, cat, page + 1).openLater(); }
        }
    }

    // =====================================================================
    // Chọn số lượng mua / bán (đổi số lượng ngay trong menu, không cần mở lại)
    // =====================================================================
    public static class DetailMenu extends Menu {
        private static final int MAX_QTY = 2304; // 36 stack
        private final ShopManager.Category cat;
        private final ShopManager.Entry en;
        private final int page;
        private int qty = 1;

        public DetailMenu(Player p, ShopManager.Category cat, ShopManager.Entry en, int page) {
            super(p);
            this.cat = cat;
            this.en = en;
            this.page = page;
        }

        @Override
        protected void build() {
            create(5, "&8Chọn số lượng");
            Gui.frame(inv);

            int[] steps = {64, 16, 1};
            for (int i = 0; i < steps.length; i++) {
                inv.setItem(10 + i, Util.item(Material.RED_STAINED_GLASS_PANE, steps[i], "&c-" + steps[i]));
                inv.setItem(16 - i, Util.item(Material.LIME_STAINED_GLASS_PANE, steps[i], "&a+" + steps[i]));
            }
            inv.setItem(38, Util.item(Material.PAPER, "&fĐặt về 1"));
            inv.setItem(42, Util.item(Material.CHEST, "&fĐặt = 1 stack", "&7(" + en.mat.getMaxStackSize() + ")"));
            inv.setItem(40, Util.item(Material.BARRIER, "&c« Quay lại"));
            update();
        }

        /** Vẽ lại phần thay đổi theo số lượng. */
        private void update() {
            int have = Util.count(player.getInventory(), en.mat);
            double buyTotal = Util.round(en.buy * qty);
            double sellTotal = Util.round(en.sell * qty);

            inv.setItem(4, Gui.balance(player));
            inv.setItem(13, Util.addLore(new ItemStack(en.mat, Math.min(qty, en.mat.getMaxStackSize())),
                    "",
                    "&8▪ &7Số lượng: &f" + qty,
                    "&8▪ &7Trong túi: &f" + have,
                    "",
                    en.canBuy() ? "&a▎ Mua  &f" + Util.full(en.buy) + " &7/cái" : "&8▎ Mua  &7Không bán",
                    en.canSell() ? "&c▎ Bán  &f" + Util.full(en.sell) + " &7/cái" : "&8▎ Bán  &7Không nhận"));

            if (en.canBuy()) {
                inv.setItem(29, Util.item(Material.LIME_CONCRETE, "&a&lMUA x" + qty,
                        "&7Tổng: &a" + Util.full(buyTotal), "", "&e» Bấm để mua"));
            } else {
                inv.setItem(29, Util.item(Material.GRAY_CONCRETE, "&8Không bán"));
            }
            if (en.canSell()) {
                inv.setItem(31, Util.item(Material.ORANGE_CONCRETE, "&6&lBÁN TẤT CẢ",
                        "&7Trong túi: &f" + have,
                        "&7Nhận: &e" + Util.full(Util.round(en.sell * have)), "", "&e» Bấm để bán"));
                inv.setItem(33, Util.item(Material.RED_CONCRETE, "&c&lBÁN x" + Math.min(qty, Math.max(have, 1)),
                        "&7Nhận: &e" + Util.full(Util.round(en.sell * Math.min(qty, have))), "", "&e» Bấm để bán"));
            } else {
                inv.setItem(31, Util.item(Material.GRAY_CONCRETE, "&8Không nhận"));
                inv.setItem(33, Util.item(Material.GRAY_CONCRETE, "&8Không nhận"));
            }
        }

        private void setQty(int q) {
            qty = Math.max(1, Math.min(MAX_QTY, q));
            update();
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            switch (s) {
                case 10 -> setQty(qty - 64);
                case 11 -> setQty(qty - 16);
                case 12 -> setQty(qty - 1);
                case 14 -> setQty(qty + 1);
                case 15 -> setQty(qty + 16);
                case 16 -> setQty(qty + 64);
                case 38 -> setQty(1);
                case 42 -> setQty(en.mat.getMaxStackSize());
                case 29 -> { if (en.canBuy()) buy(qty); }
                case 31 -> { if (en.canSell()) sell(-1); }
                case 33 -> { if (en.canSell()) sell(qty); }
                case 40 -> new CategoryMenu(player, cat, page).openLater();
                default -> { return; }
            }
            if (s != 29 && s != 31 && s != 33 && s != 40) Gui.click(player);
        }

        private void buy(int amt) {
            CustomShop pl = CustomShop.get();
            String err = pl.txError(player);
            if (err != null) { Util.msg(player, err); Gui.bad(player); return; }
            double cost = Util.round(en.buy * amt);
            if (cost < ShopManager.MIN_PRICE) {
                Util.msg(player, "&cGiá không hợp lệ.");
                return;
            }
            if (!Util.canFit(player.getInventory(), new ItemStack(en.mat), amt)) {
                Util.msg(player, "&cTúi đồ của bạn không đủ chỗ.");
                Gui.bad(player);
                return;
            }
            if (!pl.withdraw(player, cost)) {
                Util.msg(player, "&cBạn không đủ tiền (cần " + Util.full(cost) + ").");
                Gui.bad(player);
                return;
            }
            Map<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack(en.mat, amt));
            int notGiven = 0;
            for (ItemStack it : left.values()) notGiven += it.getAmount();
            if (notGiven > 0) pl.deposit(player, Util.round(en.buy * notGiven)); // hoàn tiền phần không nhận được
            int got = amt - notGiven;
            Util.msg(player, "&aĐã mua &f" + got + "x " + Util.pretty(en.mat) + " &avới giá &f" + Util.full(Util.round(en.buy * got)) + "&a.");
            Gui.good(player);
            update();
        }

        private void sell(int amt) {
            CustomShop pl = CustomShop.get();
            String err = pl.txError(player);
            if (err != null) { Util.msg(player, err); Gui.bad(player); return; }
            int have = Util.count(player.getInventory(), en.mat);
            int n = amt < 0 ? have : Math.min(amt, have);
            if (n <= 0) {
                Util.msg(player, "&cBạn không có vật phẩm này (loại thường, không đổi tên/enchant).");
                Gui.bad(player);
                return;
            }
            int removed = Util.remove(player.getInventory(), en.mat, n);
            double gain = Util.round(en.sell * removed);
            if (removed <= 0) return;
            if (!pl.deposit(player, gain)) {
                Util.give(player, new ItemStack(en.mat, removed));
                Util.msg(player, "&cKhông cộng được tiền, đã trả lại đồ cho bạn.");
                Gui.bad(player);
                update();
                return;
            }
            Util.msg(player, "&aĐã bán &f" + removed + "x " + Util.pretty(en.mat) + " &anhận &f" + Util.full(gain) + "&a.");
            Gui.good(player);
            update();
        }
    }

    // =====================================================================
    // /sell - thả đồ vào, đóng menu = bán
    // =====================================================================
    public static class SellMenu extends Menu {
        private boolean cancelled;

        public SellMenu(Player p) {
            super(p);
        }

        @Override
        public boolean interactive() { return true; }

        @Override
        public boolean isControl(int rawSlot) { return rawSlot >= 45 && rawSlot < 54; }

        @Override
        protected void build() {
            create(6, "&8Bán đồ &7- thả đồ vào đây");
            ItemStack b = Gui.border();
            for (int i = 45; i < 54; i++) inv.setItem(i, b);
            inv.setItem(45, Util.item(Material.RED_CONCRETE, "&c&lHỦY", "&7Trả lại toàn bộ đồ"));
            inv.setItem(53, Util.item(Material.LIME_CONCRETE, "&a&lBÁN", "&7Bấm để bán", "&8(đóng menu cũng tự bán)"));
            refresh();
        }

        @Override
        public void refresh() {
            ShopManager sm = CustomShop.get().shop();
            double total = 0;
            int count = 0;
            int skip = 0;
            for (int i = 0; i < 45; i++) {
                ItemStack it = inv.getItem(i);
                if (it == null || it.getType().isAir()) continue;
                double pr = sm.sellPrice(it);
                if (pr > 0) {
                    total += pr * it.getAmount();
                    count += it.getAmount();
                } else {
                    skip += it.getAmount();
                }
            }
            inv.setItem(49, Util.item(Material.GOLD_INGOT, "&aTổng: &f" + Util.full(Util.round(total)),
                    "&8▪ &7Bán được: &f" + count,
                    "&8▪ &7Không nhận (trả lại): &f" + skip,
                    "",
                    "&7Đồ đổi tên / enchant / hư sẽ được trả lại"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s == 45) {
                cancelled = true;
                closeLater();
            } else if (s == 53) {
                closeLater();
            }
        }

        @Override
        public void onClose(InventoryCloseEvent e) {
            CustomShop pl = CustomShop.get();
            ShopManager sm = pl.shop();
            boolean canPay = !cancelled && pl.hasEco() && pl.txError(player) == null;
            double total = 0;
            int count = 0;
            List<ItemStack> sold = new ArrayList<>();
            List<ItemStack> keep = new ArrayList<>();
            for (int i = 0; i < 45; i++) {
                ItemStack raw = inv.getItem(i);
                if (raw == null || raw.getType().isAir()) continue;
                inv.setItem(i, null);
                ItemStack it = raw.clone();
                double pr = canPay ? sm.sellPrice(it) : -1;
                if (pr > 0) {
                    total += pr * it.getAmount();
                    count += it.getAmount();
                    sold.add(it);
                } else {
                    keep.add(it);
                }
            }
            total = Util.round(total);
            boolean paid = false;
            if (total > 0) {
                if (pl.deposit(player, total)) {
                    paid = true;
                } else {
                    keep.addAll(sold); // cộng tiền lỗi -> trả hết đồ
                }
            }
            for (ItemStack k : keep) Util.give(player, k);
            if (paid) {
                Util.msg(player, "&aĐã bán &f" + count + " &avật phẩm, nhận được &f" + Util.full(total) + "&a.");
                Gui.good(player);
            } else if (total > 0) {
                Util.msg(player, "&cKhông cộng được tiền, đã trả lại đồ cho bạn.");
            }
        }
    }
}
