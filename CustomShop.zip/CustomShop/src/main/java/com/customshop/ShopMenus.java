package com.customshop;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public final class ShopMenus {
    private ShopMenus() {}

    // =====================================================================
    // Menu chính /shop
    // =====================================================================
    public static class MainMenu extends Menu {
        public MainMenu(Player p) {
            super(p);
        }

        @Override
        protected void build() {
            ShopManager sm = CustomShop.get().shop();
            create(6, sm.title());
            for (ShopManager.Category c : sm.categories()) {
                if (c.slot < 0 || c.slot > 44) continue;
                inv.setItem(c.slot, Util.item(c.icon, c.name, "&7" + c.items.size() + " vật phẩm", "", "&eBấm để mở"));
            }
            fill(45, 53, filler());
            inv.setItem(46, Util.item(Material.CHEST, "&6Chợ người chơi &7(/ah)", "&7Mua bán với người chơi khác", "", "&eBấm để mở"));
            inv.setItem(48, Util.item(Material.HOPPER, "&aBán đồ &7(/sell)", "&7Thả đồ vào để bán lấy tiền", "", "&eBấm để mở"));
            inv.setItem(50, Util.item(Material.WRITABLE_BOOK, "&bĐơn hàng &7(/orders)", "&7Giao hàng cho người khác lấy tiền", "", "&eBấm để mở"));
            inv.setItem(52, Util.item(Material.BARRIER, "&cĐóng"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            for (ShopManager.Category c : CustomShop.get().shop().categories()) {
                if (c.slot == s) {
                    new CategoryMenu(player, c, 0).openLater();
                    return;
                }
            }
            switch (s) {
                case 46 -> new AuctionMenus.AhMenu(player, 0, Sort.NEWEST, null).openLater();
                case 48 -> new SellMenu(player).openLater();
                case 50 -> new OrderMenus.OrdersMenu(player, 0, Sort.NEWEST).openLater();
                case 52 -> closeLater();
                default -> { }
            }
        }
    }

    // =====================================================================
    // Danh mục
    // =====================================================================
    public static class CategoryMenu extends Menu {
        private final ShopManager.Category cat;
        private int page;
        private int pages = 1;

        public CategoryMenu(Player p, ShopManager.Category cat, int page) {
            super(p);
            this.cat = cat;
            this.page = page;
        }

        @Override
        protected void build() {
            List<ShopManager.Entry> items = cat.items;
            pages = Math.max(1, (items.size() + 44) / 45);
            page = Math.max(0, Math.min(page, pages - 1));
            create(6, cat.name + " &8(" + (page + 1) + "/" + pages + ")");
            for (int i = 0; i < 45; i++) {
                int idx = page * 45 + i;
                if (idx >= items.size()) break;
                ShopManager.Entry en = items.get(idx);
                inv.setItem(i, Util.addLore(new ItemStack(en.mat),
                        "",
                        en.canBuy() ? "&7Mua: &a" + Util.money(en.buy) : "&7Mua: &cKhông bán",
                        en.canSell() ? "&7Bán: &e" + Util.money(en.sell) : "&7Bán: &cKhông nhận",
                        "",
                        "&eBấm để chọn số lượng"));
            }
            fill(45, 53, filler());
            if (page > 0) inv.setItem(45, Util.item(Material.ARROW, "&eTrang trước"));
            inv.setItem(49, Util.item(Material.BARRIER, "&cQuay lại"));
            if (page < pages - 1) inv.setItem(53, Util.item(Material.ARROW, "&eTrang sau"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s < 45) {
                int idx = page * 45 + s;
                if (idx < cat.items.size()) new DetailMenu(player, cat, cat.items.get(idx), page).openLater();
                return;
            }
            if (s == 45 && page > 0) new CategoryMenu(player, cat, page - 1).openLater();
            else if (s == 49) new MainMenu(player).openLater();
            else if (s == 53 && page < pages - 1) new CategoryMenu(player, cat, page + 1).openLater();
        }
    }

    // =====================================================================
    // Chọn số lượng mua / bán (thân thiện với điện thoại, không cần Shift)
    // =====================================================================
    public static class DetailMenu extends Menu {
        private static final int[] AMOUNTS = {1, 16, 32, 64};
        private final ShopManager.Category cat;
        private final ShopManager.Entry en;
        private final int page;

        public DetailMenu(Player p, ShopManager.Category cat, ShopManager.Entry en, int page) {
            super(p);
            this.cat = cat;
            this.en = en;
            this.page = page;
        }

        @Override
        protected void build() {
            create(4, "&8Chọn số lượng");
            fill(0, 35, filler());
            inv.setItem(4, Util.addLore(new ItemStack(en.mat),
                    "",
                    en.canBuy() ? "&7Mua: &a" + Util.money(en.buy) + "/cái" : "&7Mua: &cKhông bán",
                    en.canSell() ? "&7Bán: &e" + Util.money(en.sell) + "/cái" : "&7Bán: &cKhông nhận"));
            if (en.canBuy()) {
                for (int i = 0; i < AMOUNTS.length; i++) {
                    inv.setItem(10 + i, Util.item(Material.LIME_STAINED_GLASS_PANE, AMOUNTS[i],
                            "&aMua " + AMOUNTS[i], "&7Giá: &a" + Util.money(Util.round(en.buy * AMOUNTS[i]))));
                }
            }
            if (en.canSell()) {
                for (int i = 0; i < AMOUNTS.length; i++) {
                    inv.setItem(19 + i, Util.item(Material.RED_STAINED_GLASS_PANE, AMOUNTS[i],
                            "&cBán " + AMOUNTS[i], "&7Nhận: &e" + Util.money(Util.round(en.sell * AMOUNTS[i]))));
                }
                updateSellAll();
            }
            inv.setItem(31, Util.item(Material.ARROW, "&cQuay lại"));
        }

        private void updateSellAll() {
            int have = Util.count(player.getInventory(), en.mat);
            inv.setItem(23, Util.item(Material.ORANGE_STAINED_GLASS_PANE, "&6Bán tất cả",
                    "&7Trong túi: &f" + have, "&7Nhận: &e" + Util.money(Util.round(en.sell * have))));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s >= 10 && s <= 13 && en.canBuy()) buy(AMOUNTS[s - 10]);
            else if (s >= 19 && s <= 22 && en.canSell()) sell(AMOUNTS[s - 19]);
            else if (s == 23 && en.canSell()) sell(-1);
            else if (s == 31) new CategoryMenu(player, cat, page).openLater();
        }

        private void buy(int amt) {
            CustomShop pl = CustomShop.get();
            double cost = Util.round(en.buy * amt);
            if (!Util.canFit(player.getInventory(), new ItemStack(en.mat), amt)) {
                Util.msg(player, "&cTúi đồ của bạn không đủ chỗ.");
                return;
            }
            if (!pl.withdraw(player, cost)) {
                Util.msg(player, "&cBạn không đủ tiền (cần " + Util.money(cost) + ").");
                return;
            }
            player.getInventory().addItem(new ItemStack(en.mat, amt));
            Util.msg(player, "&aĐã mua &f" + amt + "x " + Util.pretty(en.mat) + " &avới giá &f" + Util.money(cost) + "&a.");
            if (en.canSell()) updateSellAll();
        }

        private void sell(int amt) {
            int have = Util.count(player.getInventory(), en.mat);
            int n = amt < 0 ? have : Math.min(amt, have);
            if (n <= 0) {
                Util.msg(player, "&cBạn không có vật phẩm này (loại thường, không đổi tên/enchant).");
                return;
            }
            int removed = Util.remove(player.getInventory(), en.mat, n);
            double gain = Util.round(en.sell * removed);
            CustomShop.get().deposit(player, gain);
            Util.msg(player, "&aĐã bán &f" + removed + "x " + Util.pretty(en.mat) + " &anhận &f" + Util.money(gain) + "&a.");
            updateSellAll();
        }
    }

    // =====================================================================
    // /sell - thả đồ vào, đóng menu = bán
    // =====================================================================
    public static class SellMenu extends Menu {
        private boolean cancelled;

        public SellMenu(Player p) {
            super(p);
        }

        @Override
        public boolean interactive() { return true; }

        @Override
        public boolean isControl(int rawSlot) { return rawSlot >= 45 && rawSlot < 54; }

        @Override
        protected void build() {
            create(6, "&8Bán đồ - thả đồ vào đây");
            fill(45, 53, filler());
            inv.setItem(45, Util.item(Material.RED_CONCRETE, "&cHủy", "&7Trả lại toàn bộ đồ"));
            inv.setItem(53, Util.item(Material.LIME_CONCRETE, "&a&lBÁN", "&7Bấm để bán (đóng menu cũng tự bán)"));
            refresh();
        }

        @Override
        public void refresh() {
            ShopManager sm = CustomShop.get().shop();
            double total = 0;
            int count = 0;
            for (int i = 0; i < 45; i++) {
                ItemStack it = inv.getItem(i);
                if (it == null) continue;
                double pr = sm.sellPrice(it);
                if (pr > 0) {
                    total += pr * it.getAmount();
                    count += it.getAmount();
                }
            }
            inv.setItem(49, Util.item(Material.GOLD_INGOT, "&aTổng: &f" + Util.money(Util.round(total)),
                    "&7Vật phẩm bán được: &f" + count, "",
                    "&7Đồ không bán được sẽ được trả lại"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s == 45) {
                cancelled = true;
                closeLater();
            } else if (s == 53) {
                closeLater();
            }
        }

        @Override
        public void onClose(InventoryCloseEvent e) {
            CustomShop pl = CustomShop.get();
            ShopManager sm = pl.shop();
            boolean canPay = !cancelled && pl.hasEco();
            double total = 0;
            int count = 0;
            for (int i = 0; i < 45; i++) {
                ItemStack raw = inv.getItem(i);
                if (raw == null || raw.getType().isAir()) continue;
                inv.setItem(i, null);
                ItemStack it = raw.clone();
                double pr = canPay ? sm.sellPrice(it) : -1;
                if (pr > 0) {
                    total += pr * it.getAmount();
                    count += it.getAmount();
                } else {
                    Util.give(player, it);
                }
            }
            if (total > 0) {
                total = Util.round(total);
                pl.deposit(player, total);
                Util.msg(player, "&aĐã bán &f" + count + " &avật phẩm, nhận được &f" + Util.money(total) + "&a.");
            }
        }
    }
}
