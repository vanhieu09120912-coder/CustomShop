package com.customshop;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

/** Khung giao diện dùng chung: viền, ô lưới 7x4, âm thanh. */
public final class Gui {
    private Gui() {}

    /** 28 ô bên trong khung của menu 6 hàng (7 cột x 4 hàng). */
    public static final int[] GRID = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43};
    public static final int PER_PAGE = GRID.length;

    private static final int[] SLOT_INDEX = new int[54];

    static {
        for (int i = 0; i < SLOT_INDEX.length; i++) SLOT_INDEX[i] = -1;
        for (int i = 0; i < GRID.length; i++) SLOT_INDEX[GRID[i]] = i;
    }

    /** Vị trí (0-27) của ô trong lưới, -1 nếu không thuộc lưới. */
    public static int gridIndex(int slot) {
        return (slot >= 0 && slot < SLOT_INDEX.length) ? SLOT_INDEX[slot] : -1;
    }

    public static int pages(int total) {
        return Math.max(1, (total + PER_PAGE - 1) / PER_PAGE);
    }

    private static Material mat(String path, String def) {
        String name = CustomShop.get().getConfig().getString(path, def);
        Material m = Material.matchMaterial(name == null ? def : name);
        if (m == null || !m.isItem()) m = Material.matchMaterial(def);
        return m == null ? Material.GRAY_STAINED_GLASS_PANE : m;
    }

    public static ItemStack border() { return Util.item(mat("gui.border", "BLACK_STAINED_GLASS_PANE"), " "); }
    public static ItemStack accent() { return Util.item(mat("gui.accent", "CYAN_STAINED_GLASS_PANE"), " "); }
    public static ItemStack fill() { return Util.item(mat("gui.fill", "GRAY_STAINED_GLASS_PANE"), " "); }

    /** Vẽ khung: viền ngoài + nền xám bên trong + 4 góc màu nhấn. */
    public static void frame(Inventory inv) {
        int size = inv.getSize();
        int rows = size / 9;
        ItemStack b = border();
        ItemStack f = fill();
        for (int i = 0; i < size; i++) {
            int r = i / 9;
            int c = i % 9;
            boolean edge = r == 0 || r == rows - 1 || c == 0 || c == 8;
            inv.setItem(i, edge ? b : f);
        }
        ItemStack a = accent();
        inv.setItem(0, a);
        inv.setItem(8, a);
        inv.setItem(size - 9, a);
        inv.setItem(size - 1, a);
    }

    public static ItemStack balance(Player p) {
        return Util.head(p, "&f" + p.getName(),
                "&7Số dư: &a" + Util.full(CustomShop.get().balance(p)));
    }

    // ---------- Âm thanh ----------
    private static void play(Player p, Sound s, float pitch) {
        try {
            Location l = p.getLocation();
            p.playSound(l, s, 0.6f, pitch);
        } catch (Throwable ignored) {
            // không quan trọng
        }
    }

    public static void click(Player p) { play(p, Sound.UI_BUTTON_CLICK, 1.2f); }
    public static void good(Player p) { play(p, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.3f); }
    public static void bad(Player p) { play(p, Sound.ENTITY_VILLAGER_NO, 1.0f); }
}
