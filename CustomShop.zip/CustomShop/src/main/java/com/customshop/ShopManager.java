package com.customshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ShopManager {
    public static class Entry {
        public final Material mat;
        public final double buy, sell;

        Entry(Material mat, double buy, double sell) {
            this.mat = mat;
            this.buy = buy;
            this.sell = sell;
        }

        public boolean canBuy() { return buy > 0; }
        public boolean canSell() { return sell > 0; }
    }

    public static class Category {
        public String id, name;
        public Material icon = Material.CHEST;
        public int slot = -1;
        public final List<Entry> items = new ArrayList<>();
    }

    private final CustomShop plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();
    private final Map<Material, Entry> byMat = new HashMap<>();
    private String title = "&8Shop";

    public ShopManager(CustomShop plugin) {
        this.plugin = plugin;
    }

    public void load() {
        categories.clear();
        byMat.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "shop.yml"));
        title = y.getString("title", "&8Shop");
        ConfigurationSection root = y.getConfigurationSection("categories");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Category c = new Category();
            c.id = id.toLowerCase();
            c.name = s.getString("name", id);
            Material ic = Material.matchMaterial(s.getString("icon", "CHEST"));
            if (ic != null) c.icon = ic;
            c.slot = s.getInt("slot", -1);
            for (String line : s.getStringList("items")) {
                String[] p = line.trim().split("\\s+");
                if (p.length < 3) {
                    plugin.getLogger().warning("shop.yml: dòng sai định dạng: " + line);
                    continue;
                }
                Material m = Material.matchMaterial(p[0]);
                if (m == null || !m.isItem()) {
                    plugin.getLogger().warning("shop.yml: không có vật phẩm: " + p[0]);
                    continue;
                }
                Entry en = new Entry(m, Util.parseMoney(p[1]), Util.parseMoney(p[2]));
                c.items.add(en);
                Entry old = byMat.get(m);
                if (old == null || (!old.canSell() && en.canSell())) byMat.put(m, en);
            }
            categories.put(c.id, c);
        }
    }

    public String title() { return title; }
    public Collection<Category> categories() { return categories.values(); }
    public Set<String> categoryIds() { return categories.keySet(); }
    public Category category(String id) { return categories.get(id); }

    /** Giá bán 1 cái; chỉ item "thường" (không đổi tên/enchant) mới bán được. -1 = không bán được. */
    public double sellPrice(ItemStack it) {
        if (it == null || it.getType().isAir() || it.hasItemMeta()) return -1;
        Entry e = byMat.get(it.getType());
        return (e != null && e.canSell()) ? e.sell : -1;
    }

    /** /sell hand, /sell all */
    public void sellFromInventory(Player p, boolean handOnly) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] c = inv.getStorageContents();
        double total = 0;
        int count = 0;
        for (int i = 0; i < c.length; i++) {
            if (handOnly && i != inv.getHeldItemSlot()) continue;
            ItemStack it = c[i];
            if (it == null) continue;
            double price = sellPrice(it);
            if (price <= 0) continue;
            total += price * it.getAmount();
            count += it.getAmount();
            c[i] = null;
        }
        if (total <= 0) {
            Util.msg(p, "&cKhông có vật phẩm nào bán được.");
            return;
        }
        inv.setStorageContents(c);
        total = Util.round(total);
        plugin.deposit(p, total);
        Util.msg(p, "&aĐã bán &f" + count + " &avật phẩm, nhận được &f" + Util.money(total) + "&a.");
    }
}
