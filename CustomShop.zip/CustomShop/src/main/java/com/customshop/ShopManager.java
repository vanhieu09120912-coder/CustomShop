package com.customshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ShopManager {
    /** Giá nhỏ nhất hợp lệ cho 1 vật phẩm; nhỏ hơn thì coi như lỗi cấu hình (tránh mua 0 đồng do làm tròn). */
    public static final double MIN_PRICE = 0.01;

    public static class Entry {
        public final Material mat;
        public double buy, sell;

        Entry(Material mat, double buy, double sell) {
            this.mat = mat;
            this.buy = buy;
            this.sell = sell;
        }

        public boolean canBuy() { return buy >= MIN_PRICE; }
        public boolean canSell() { return sell >= MIN_PRICE; }
    }

    public static class Category {
        public String id, name;
        public Material icon = Material.CHEST;
        public int slot = -1;
        public final List<String> lore = new ArrayList<>();
        public final List<Entry> items = new ArrayList<>();
    }

    private final CustomShop plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();
    private final Map<Material, Entry> byMat = new HashMap<>();
    private String title = "&8Shop";

    public ShopManager(CustomShop plugin) {
        this.plugin = plugin;
    }

    public double ratio() {
        double r = plugin.getConfig().getDouble("safety.max-sell-ratio", 0.5);
        if (!Util.validMoney(r) || r <= 0 || r > 1) r = 0.5;
        return r;
    }

    public void load() {
        categories.clear();
        byMat.clear();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "shop.yml"));
        title = y.getString("title", "&8Shop");
        ConfigurationSection root = y.getConfigurationSection("categories");
        if (root == null) return;
        double ratio = ratio();
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Category c = new Category();
            c.id = id.toLowerCase();
            c.name = s.getString("name", id);
            Material ic = Material.matchMaterial(s.getString("icon", "CHEST"));
            if (ic != null) c.icon = ic;
            c.slot = s.getInt("slot", -1);
            c.lore.addAll(s.getStringList("lore"));
            for (String line : s.getStringList("items")) {
                String[] p = line.trim().split("\\s+");
                if (p.length < 3) {
                    plugin.getLogger().warning("shop.yml: dòng sai định dạng: " + line);
                    continue;
                }
                Material m = Material.matchMaterial(p[0]);
                if (m == null || !m.isItem()) {
                    plugin.getLogger().warning("shop.yml: không có vật phẩm: " + p[0]);
                    continue;
                }
                if (plugin.isBlocked(m)) {
                    plugin.getLogger().warning("shop.yml: bỏ qua " + m.name() + " (nằm trong danh sách cấm / spawner).");
                    continue;
                }
                if (byMat.containsKey(m)) {
                    plugin.getLogger().warning("shop.yml: " + m.name() + " bị khai báo 2 lần, chỉ dùng dòng đầu tiên.");
                    continue;
                }
                double buy = Util.parseMoney(p[1]);
                double sell = Util.parseMoney(p[2]);
                if (buy > 0 && buy < MIN_PRICE) {
                    plugin.getLogger().warning("shop.yml: giá mua " + m.name() + " quá nhỏ, đã tắt mua.");
                    buy = -1;
                }
                if (sell > 0 && sell < MIN_PRICE) sell = -1;
                // Giá bán không được cao hơn giá mua * tỉ lệ (chống mua đi bán lại ra lời)
                if (buy > 0 && sell > 0 && sell > buy * ratio) {
                    double fixed = Util.round(buy * ratio);
                    plugin.getLogger().warning("shop.yml: " + m.name() + " bán " + sell + " > mua " + buy
                            + " x " + ratio + ", đã hạ giá bán xuống " + fixed + ".");
                    sell = fixed < MIN_PRICE ? -1 : fixed;
                }
                Entry en = new Entry(m, buy, sell);
                c.items.add(en);
                byMat.put(m, en);
            }
            categories.put(c.id, c);
        }
    }

    public String title() { return title; }
    public Collection<Category> categories() { return categories.values(); }
    public Set<String> categoryIds() { return categories.keySet(); }
    public Category category(String id) { return categories.get(id); }
    public Collection<Entry> entries() { return byMat.values(); }

    /** Quét công thức craft/nung/stonecutter; hạ giá bán nếu có đường mua rẻ -> bán lời. */
    public List<String> audit() {
        List<String> report;
        try {
            report = PriceGuard.run(plugin, this);
        } catch (Throwable t) {
            plugin.getLogger().warning("Không quét được giá: " + t);
            report = new ArrayList<>();
            report.add("Lỗi khi quét: " + t);
        }
        if (report.isEmpty()) {
            plugin.getLogger().info("Quét giá: không phát hiện cách mua-craft-bán ra lời.");
        } else {
            for (String s : report) plugin.getLogger().warning("Quét giá: " + s);
        }
        return report;
    }

    /** Giá bán 1 cái; chỉ item "thường" (không đổi tên/enchant) mới bán được. -1 = không bán được. */
    public double sellPrice(ItemStack it) {
        if (it == null || it.getType().isAir() || it.hasItemMeta() || it.getAmount() <= 0) return -1;
        if (plugin.isBlocked(it.getType())) return -1;
        Entry e = byMat.get(it.getType());
        return (e != null && e.canSell()) ? e.sell : -1;
    }

    /** /sell hand, /sell all. Trừ đồ trước, cộng tiền sau; cộng tiền lỗi thì trả đồ lại. */
    public void sellFromInventory(Player p, boolean handOnly) {
        String err = plugin.txError(p);
        if (err != null) {
            Util.msg(p, err);
            return;
        }
        PlayerInventory inv = p.getInventory();
        ItemStack[] c = inv.getStorageContents();
        ItemStack[] backup = new ItemStack[c.length];
        double total = 0;
        int count = 0;
        for (int i = 0; i < c.length; i++) {
            if (handOnly && i != inv.getHeldItemSlot()) continue;
            ItemStack it = c[i];
            if (it == null) continue;
            double price = sellPrice(it);
            if (price <= 0) continue;
            total += price * it.getAmount();
            count += it.getAmount();
            backup[i] = it.clone();
            c[i] = null;
        }
        total = Util.round(total);
        if (total <= 0 || count <= 0) {
            Util.msg(p, "&cKhông có vật phẩm nào bán được.");
            Gui.bad(p);
            return;
        }
        inv.setStorageContents(c);
        if (!plugin.deposit(p, total)) {
            for (int i = 0; i < c.length; i++) if (backup[i] != null) c[i] = backup[i];
            inv.setStorageContents(c);
            Util.msg(p, "&cKhông cộng được tiền, đã trả lại đồ cho bạn.");
            Gui.bad(p);
            return;
        }
        Util.msg(p, "&aĐã bán &f" + count + " &avật phẩm, nhận được &f" + Util.full(total) + "&a.");
        Gui.good(p);
    }
}
