package com.customshop;

import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class Commands implements CommandExecutor, TabCompleter {
    private final CustomShop plugin;
    private List<String> materialNames;

    public Commands(CustomShop plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);

        if (n.equals("shop") && a.length > 0 && a[0].equalsIgnoreCase("reload")) {
            if (!s.hasPermission("customshop.admin")) {
                Util.msg(s, "&cBạn không có quyền.");
                return true;
            }
            plugin.reloadAll();
            Util.msg(s, "&aĐã tải lại config.yml và shop.yml (đã quét lại giá, xem /shop audit).");
            return true;
        }

        if (n.equals("shop") && a.length > 0 && a[0].equalsIgnoreCase("audit")) {
            if (!s.hasPermission("customshop.admin")) {
                Util.msg(s, "&cBạn không có quyền.");
                return true;
            }
            List<String> report = plugin.shop().audit();
            if (report.isEmpty()) {
                Util.msg(s, "&aKhông phát hiện cách mua-craft-bán ra lời.");
            } else {
                Util.msg(s, "&eTìm thấy &f" + report.size() + " &emục giá có thể bị lợi dụng:");
                for (int i = 0; i < Math.min(12, report.size()); i++) Util.msg(s, "&7- " + report.get(i));
                if (report.size() > 12) Util.msg(s, "&7... và " + (report.size() - 12) + " mục nữa (xem console).");
            }
            return true;
        }

        if (!(s instanceof Player p)) {
            Util.msg(s, "&cLệnh này chỉ dùng trong game.");
            return true;
        }
        if (!plugin.hasEco()) {
            Util.msg(p, "&cChưa có plugin kinh tế. Cần cài Vault + một plugin tiền (vd EssentialsX).");
            return true;
        }

        switch (n) {
            case "shop" -> shop(p, a);
            case "ah" -> ah(p, a);
            case "sell" -> sell(p, a);
            case "orders" -> orders(p, a);
            default -> { return false; }
        }
        return true;
    }

    private void shop(Player p, String[] a) {
        if (a.length > 0) {
            ShopManager.Category c = plugin.shop().category(a[0].toLowerCase(Locale.ROOT));
            if (c != null) {
                new ShopMenus.CategoryMenu(p, c, 0).open();
                return;
            }
        }
        new ShopMenus.MainMenu(p).open();
    }

    private void ah(Player p, String[] a) {
        if (a.length >= 1 && (a[0].equalsIgnoreCase("sell") || a[0].equalsIgnoreCase("ban"))) {
            if (a.length < 2) {
                Util.msg(p, "&eDùng: &f/ah sell <giá> &7(cầm vật phẩm trên tay, vd &f/ah sell 1.5k&7)");
                return;
            }
            double price = Util.parseMoney(a[1]);
            if (!(price > 0)) {
                Util.msg(p, "&cGiá không hợp lệ.");
                return;
            }
            String err = plugin.auctions().list(p, p.getInventory().getItemInMainHand(), price);
            if (err != null) Util.msg(p, err);
            return;
        }
        String filter = a.length > 0 ? String.join(" ", a) : null;
        new AuctionMenus.AhMenu(p, 0, Sort.NEWEST, filter).open();
    }

    private void sell(Player p, String[] a) {
        if (a.length == 0) {
            new ShopMenus.SellMenu(p).open();
        } else if (a[0].equalsIgnoreCase("hand")) {
            plugin.shop().sellFromInventory(p, true);
        } else if (a[0].equalsIgnoreCase("all")) {
            plugin.shop().sellFromInventory(p, false);
        } else {
            Util.msg(p, "&eDùng: &f/sell &7| &f/sell hand &7| &f/sell all");
        }
    }

    private void orders(Player p, String[] a) {
        if (a.length == 0) {
            new OrderMenus.OrdersMenu(p, 0, Sort.NEWEST).open();
            return;
        }
        if (a[0].equalsIgnoreCase("my")) {
            new OrderMenus.MyOrdersMenu(p, 0).open();
            return;
        }
        if (a[0].equalsIgnoreCase("create") || a[0].equalsIgnoreCase("tao")) {
            if (a.length < 3) {
                Util.msg(p, "&eDùng: &f/orders create <số lượng> <giá mỗi cái> [vật phẩm]");
                Util.msg(p, "&7Không ghi vật phẩm = lấy vật phẩm đang cầm trên tay. Ví dụ: &f/orders create 64 10 diamond");
                return;
            }
            int amount;
            try {
                amount = Integer.parseInt(a[1]);
            } catch (NumberFormatException ex) {
                Util.msg(p, "&cSố lượng không hợp lệ.");
                return;
            }
            double price = Util.parseMoney(a[2]);
            if (!(price > 0)) {
                Util.msg(p, "&cGiá không hợp lệ.");
                return;
            }
            Material mat;
            if (a.length >= 4) {
                mat = Material.matchMaterial(a[3]);
            } else {
                Material h = p.getInventory().getItemInMainHand().getType();
                mat = h.isAir() ? null : h;
            }
            String err = plugin.orders().create(p, mat, amount, price);
            if (err != null) Util.msg(p, err);
            return;
        }
        new OrderMenus.OrdersMenu(p, 0, Sort.NEWEST).open();
    }

    // ---------- Tab ----------
    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        if (a.length == 1) {
            List<String> opts = new ArrayList<>();
            switch (n) {
                case "shop" -> {
                    opts.addAll(plugin.shop().categoryIds());
                    if (s.hasPermission("customshop.admin")) {
                        opts.add("reload");
                        opts.add("audit");
                    }
                }
                case "ah" -> opts.add("sell");
                case "sell" -> {
                    opts.add("hand");
                    opts.add("all");
                }
                case "orders" -> {
                    opts.add("create");
                    opts.add("my");
                }
                default -> { }
            }
            return filter(opts, a[0]);
        }
        if (n.equals("orders") && a.length == 4 && a[0].equalsIgnoreCase("create")) {
            return filter(materials(), a[3]);
        }
        return Collections.emptyList();
    }

    private List<String> materials() {
        if (materialNames == null) {
            materialNames = new ArrayList<>();
            for (Material m : Material.values()) {
                if (!m.isLegacy() && m.isItem() && !m.isAir()) materialNames.add(m.name().toLowerCase(Locale.ROOT));
            }
        }
        return materialNames;
    }

    private List<String> filter(List<String> opts, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        for (String o : opts) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) {
                out.add(o);
                if (out.size() >= 40) break;
            }
        }
        return out;
    }
}
