package com.customshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Chợ người chơi. Mọi thay đổi quan trọng đều được lưu NGAY (ghi file tạm rồi đổi tên),
 * để server sập giữa chừng không gây nhân đôi đồ hoặc tiền.
 * Thứ tự luôn là "lấy đồ / xóa listing + lưu" trước, "trả tiền / đưa đồ" sau: nếu có sự cố thì mất đồ chứ không bị nhân đôi.
 */
public class AuctionManager {
    public static class Listing {
        public long id;
        public UUID seller;
        public String sellerName;
        public double price;
        public long created, expires;
        public boolean expired;
        public ItemStack item;

        public String label() {
            return item.getAmount() + "x " + Util.pretty(item.getType());
        }
    }

    private final CustomShop plugin;
    private final File file;
    private final Map<Long, Listing> listings = new LinkedHashMap<>();
    private long nextId = 1;

    public AuctionManager(CustomShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "auctions.yml");
    }

    // ---------- Lưu / tải ----------
    public void load() {
        listings.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection root = y.getConfigurationSection("listings");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(key);
            if (c == null) continue;
            ItemStack item = c.getItemStack("item");
            String seller = c.getString("seller");
            if (item == null || seller == null) continue;
            try {
                Listing l = new Listing();
                l.id = Long.parseLong(key);
                l.seller = UUID.fromString(seller);
                l.sellerName = c.getString("name", "?");
                l.price = c.getDouble("price");
                l.created = c.getLong("created");
                l.expires = c.getLong("expires");
                l.expired = c.getBoolean("expired");
                l.item = item;
                listings.put(l.id, l);
                nextId = Math.max(nextId, l.id + 1);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Bỏ qua listing lỗi: " + key);
            }
        }
    }

    public synchronized void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Listing l : listings.values()) {
            String p = "listings." + l.id + ".";
            y.set(p + "seller", l.seller.toString());
            y.set(p + "name", l.sellerName);
            y.set(p + "price", l.price);
            y.set(p + "created", l.created);
            y.set(p + "expires", l.expires);
            y.set(p + "expired", l.expired);
            y.set(p + "item", l.item);
        }
        try {
            File tmp = new File(plugin.getDataFolder(), "auctions.yml.tmp");
            y.save(tmp);
            try {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException ex) {
            plugin.getLogger().severe("Không lưu được auctions.yml: " + ex.getMessage());
        }
    }

    // ---------- Truy vấn ----------
    public Listing get(long id) {
        return listings.get(id);
    }

    /** Danh sách đang bán (chưa hết hạn), có lọc theo tên vật phẩm và sắp xếp. */
    public List<Listing> browse(String filter, Sort sort) {
        String f = filter == null ? null : filter.toLowerCase().trim().replace(' ', '_');
        long now = System.currentTimeMillis();
        List<Listing> out = new ArrayList<>();
        for (Listing l : listings.values()) {
            if (l.expired || now >= l.expires) continue;
            if (f != null && !l.item.getType().name().toLowerCase().contains(f)) continue;
            out.add(l);
        }
        switch (sort) {
            case NEWEST -> out.sort((a, b) -> Long.compare(b.created, a.created));
            case PRICE_ASC -> out.sort((a, b) -> Double.compare(a.price, b.price));
            case PRICE_DESC -> out.sort((a, b) -> Double.compare(b.price, a.price));
        }
        return out;
    }

    /** Tất cả listing của một người (gồm cả đã hết hạn), mới nhất trước. */
    public List<Listing> of(UUID uuid) {
        List<Listing> out = new ArrayList<>();
        for (Listing l : listings.values()) if (l.seller.equals(uuid)) out.add(l);
        out.sort((a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    private double tax() {
        double t = plugin.getConfig().getDouble("auction.tax-percent", 5);
        if (!Util.validMoney(t)) t = 5;
        return Math.max(0, Math.min(100, t)); // không cho âm (in tiền) hay >100 (trừ tiền người bán)
    }

    // ---------- Hành động (trả về lỗi dạng text, null = thành công) ----------
    public String list(Player p, ItemStack hand, double price) {
        String tx = plugin.txError(p);
        if (tx != null) return tx;
        FileConfiguration c = plugin.getConfig();
        if (hand == null || hand.getType().isAir()) return "&cHãy cầm vật phẩm muốn bán trên tay.";
        if (plugin.isBlocked(hand.getType())) return "&cVật phẩm này không được phép đăng bán.";
        if (!Util.validMoney(price)) return "&cGiá không hợp lệ.";
        double min = Math.max(ShopManager.MIN_PRICE, c.getDouble("auction.min-price", 1));
        double max = c.getDouble("auction.max-price", 1_000_000_000_000d);
        if (price < min) return "&cGiá tối thiểu là " + Util.full(min) + ".";
        if (price > max) return "&cGiá tối đa là " + Util.full(max) + ".";
        int limit = c.getInt("auction.max-listings", 10);
        int mine = 0;
        for (Listing l : listings.values()) if (l.seller.equals(p.getUniqueId())) mine++;
        if (mine >= limit) return "&cBạn chỉ được đăng tối đa " + limit + " vật phẩm.";

        Listing l = new Listing();
        l.id = nextId++;
        l.seller = p.getUniqueId();
        l.sellerName = p.getName();
        l.price = Util.round(price);
        l.created = System.currentTimeMillis();
        l.expires = l.created + (long) (c.getDouble("auction.duration-hours", 48) * 3_600_000d);
        l.item = hand.clone();

        // lấy đồ khỏi tay TRƯỚC, rồi mới ghi listing (sập giữa chừng chỉ mất đồ, không nhân đôi)
        p.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        listings.put(l.id, l);
        save();
        Util.msg(p, "&aĐã đăng bán &f" + l.label() + " &avới giá &f" + Util.full(l.price) + "&a.");
        return null;
    }

    public String buy(Player buyer, long id) {
        String tx = plugin.txError(buyer);
        if (tx != null) return tx;
        Listing l = listings.get(id);
        if (l == null || l.expired || System.currentTimeMillis() >= l.expires) return "&cVật phẩm này không còn nữa.";
        if (l.seller.equals(buyer.getUniqueId())) return "&cBạn không thể tự mua đồ của mình.";
        if (!Util.canFit(buyer.getInventory(), l.item, l.item.getAmount())) return "&cTúi đồ của bạn không đủ chỗ.";

        double price = l.price;
        if (plugin.balance(buyer) < price) return "&cBạn không đủ tiền (cần " + Util.full(price) + ").";
        double tax = tax();
        double net = Util.round(price * (1 - tax / 100d));

        // 1) gỡ listing + lưu ngay: từ đây không ai mua lại được
        listings.remove(id);
        save();

        // 2) trừ tiền người mua
        if (!plugin.withdraw(buyer, price)) {
            listings.put(id, l);
            save();
            return "&cBạn không đủ tiền (cần " + Util.full(price) + ").";
        }
        // 3) trả tiền người bán; lỗi thì hoàn tiền người mua và trả listing về
        if (!plugin.deposit(Bukkit.getOfflinePlayer(l.seller), net)) {
            plugin.deposit(buyer, price);
            listings.put(id, l);
            save();
            return "&cGiao dịch lỗi, đã hoàn tiền cho bạn.";
        }
        // 4) đưa đồ
        Util.give(buyer, l.item.clone());
        Util.msg(buyer, "&aĐã mua &f" + l.label() + " &avới giá &f" + Util.full(price) + "&a.");
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) {
            Util.msg(seller, "&e" + buyer.getName() + " &7đã mua &f" + l.label() + "&7, bạn nhận &a" + Util.full(net) + " &7(đã trừ thuế " + tax + "%).");
        }
        return null;
    }

    /** Thu hồi vật phẩm của chính mình (đang bán hoặc đã hết hạn). */
    public String retrieve(Player p, long id) {
        Listing l = listings.get(id);
        if (l == null || !l.seller.equals(p.getUniqueId())) return "&cVật phẩm này không còn nữa.";
        if (!Util.canFit(p.getInventory(), l.item, l.item.getAmount())) return "&cTúi đồ của bạn không đủ chỗ.";
        listings.remove(id);
        save();
        Util.give(p, l.item.clone());
        Util.msg(p, "&aĐã nhận lại &f" + l.label() + "&a.");
        return null;
    }

    /** Gọi định kỳ: đánh dấu hết hạn. */
    public void tick() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (Listing l : listings.values()) {
            if (!l.expired && now >= l.expires) {
                l.expired = true;
                changed = true;
                Player p = Bukkit.getPlayer(l.seller);
                if (p != null) {
                    Util.msg(p, "&eVật phẩm &f" + l.label() + " &ecủa bạn đã hết hạn. Vào &f/ah &e→ &fITEM CỦA BẠN &eđể nhận lại.");
                }
            }
        }
        if (changed) save();
    }
}
