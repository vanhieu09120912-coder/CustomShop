package com.customshop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class AuctionManager {
    public static class Listing {
        public long id;
        public UUID seller;
        public String sellerName;
        public double price;
        public long created, expires;
        public boolean expired;
        public ItemStack item;

        public String label() {
            return item.getAmount() + "x " + Util.pretty(item.getType());
        }
    }

    private final CustomShop plugin;
    private final File file;
    private final Map<Long, Listing> listings = new LinkedHashMap<>();
    private long nextId = 1;
    private boolean dirty;

    public AuctionManager(CustomShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "auctions.yml");
    }

    // ---------- Lưu / tải ----------
    public void load() {
        listings.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        nextId = y.getLong("next-id", 1);
        ConfigurationSection root = y.getConfigurationSection("listings");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection c = root.getConfigurationSection(key);
            if (c == null) continue;
            ItemStack item = c.getItemStack("item");
            String seller = c.getString("seller");
            if (item == null || seller == null) continue;
            try {
                Listing l = new Listing();
                l.id = Long.parseLong(key);
                l.seller = UUID.fromString(seller);
                l.sellerName = c.getString("name", "?");
                l.price = c.getDouble("price");
                l.created = c.getLong("created");
                l.expires = c.getLong("expires");
                l.expired = c.getBoolean("expired");
                l.item = item;
                listings.put(l.id, l);
                nextId = Math.max(nextId, l.id + 1);
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Bỏ qua listing lỗi: " + key);
            }
        }
    }

    public void save() {
        dirty = false;
        YamlConfiguration y = new YamlConfiguration();
        y.set("next-id", nextId);
        for (Listing l : listings.values()) {
            String p = "listings." + l.id + ".";
            y.set(p + "seller", l.seller.toString());
            y.set(p + "name", l.sellerName);
            y.set(p + "price", l.price);
            y.set(p + "created", l.created);
            y.set(p + "expires", l.expires);
            y.set(p + "expired", l.expired);
            y.set(p + "item", l.item);
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            dirty = true;
            plugin.getLogger().severe("Không lưu được auctions.yml: " + ex.getMessage());
        }
    }

    public void saveIfDirty() {
        if (dirty) save();
    }

    // ---------- Truy vấn ----------
    public Listing get(long id) {
        return listings.get(id);
    }

    /** Danh sách đang bán (chưa hết hạn), có lọc theo tên vật phẩm và sắp xếp. */
    public List<Listing> browse(String filter, Sort sort) {
        String f = filter == null ? null : filter.toLowerCase().trim().replace(' ', '_');
        List<Listing> out = new ArrayList<>();
        for (Listing l : listings.values()) {
            if (l.expired) continue;
            if (f != null && !l.item.getType().name().toLowerCase().contains(f)) continue;
            out.add(l);
        }
        switch (sort) {
            case NEWEST -> out.sort((a, b) -> Long.compare(b.created, a.created));
            case PRICE_ASC -> out.sort((a, b) -> Double.compare(a.price, b.price));
            case PRICE_DESC -> out.sort((a, b) -> Double.compare(b.price, a.price));
        }
        return out;
    }

    /** Tất cả listing của một người (gồm cả đã hết hạn), mới nhất trước. */
    public List<Listing> of(UUID uuid) {
        List<Listing> out = new ArrayList<>();
        for (Listing l : listings.values()) if (l.seller.equals(uuid)) out.add(l);
        out.sort((a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    // ---------- Hành động (trả về lỗi dạng text, null = thành công) ----------
    public String list(Player p, ItemStack hand, double price) {
        FileConfiguration c = plugin.getConfig();
        if (hand == null || hand.getType().isAir()) return "&cHãy cầm vật phẩm muốn bán trên tay.";
        double min = c.getDouble("auction.min-price", 1);
        double max = c.getDouble("auction.max-price", 1_000_000_000_000d);
        if (price < min) return "&cGiá tối thiểu là " + Util.money(min) + ".";
        if (price > max) return "&cGiá tối đa là " + Util.money(max) + ".";
        int limit = c.getInt("auction.max-listings", 10);
        int mine = 0;
        for (Listing l : listings.values()) if (l.seller.equals(p.getUniqueId())) mine++;
        if (mine >= limit) return "&cBạn chỉ được đăng tối đa " + limit + " vật phẩm.";

        Listing l = new Listing();
        l.id = nextId++;
        l.seller = p.getUniqueId();
        l.sellerName = p.getName();
        l.price = Util.round(price);
        l.created = System.currentTimeMillis();
        l.expires = l.created + (long) (c.getDouble("auction.duration-hours", 48) * 3_600_000d);
        l.item = hand.clone();
        listings.put(l.id, l);
        p.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
        dirty = true;
        Util.msg(p, "&aĐã đăng bán &f" + l.label() + " &avới giá &f" + Util.money(l.price) + "&a.");
        return null;
    }

    public String buy(Player buyer, long id) {
        Listing l = listings.get(id);
        if (l == null || l.expired) return "&cVật phẩm này không còn nữa.";
        if (l.seller.equals(buyer.getUniqueId())) return "&cBạn không thể tự mua đồ của mình.";
        if (!Util.canFit(buyer.getInventory(), l.item, l.item.getAmount())) return "&cTúi đồ của bạn không đủ chỗ.";
        if (!plugin.withdraw(buyer, l.price)) return "&cBạn không đủ tiền (cần " + Util.money(l.price) + ").";

        listings.remove(id);
        dirty = true;
        double tax = plugin.getConfig().getDouble("auction.tax-percent", 5);
        double net = Util.round(l.price * (1 - tax / 100d));
        plugin.deposit(Bukkit.getOfflinePlayer(l.seller), net);
        Util.give(buyer, l.item.clone());
        Util.msg(buyer, "&aĐã mua &f" + l.label() + " &avới giá &f" + Util.money(l.price) + "&a.");
        Player seller = Bukkit.getPlayer(l.seller);
        if (seller != null) {
            Util.msg(seller, "&e" + buyer.getName() + " &7đã mua &f" + l.label() + "&7, bạn nhận &a" + Util.money(net) + " &7(đã trừ thuế " + tax + "%).");
        }
        return null;
    }

    /** Thu hồi vật phẩm của chính mình (đang bán hoặc đã hết hạn). */
    public String retrieve(Player p, long id) {
        Listing l = listings.get(id);
        if (l == null || !l.seller.equals(p.getUniqueId())) return "&cVật phẩm này không còn nữa.";
        if (!Util.canFit(p.getInventory(), l.item, l.item.getAmount())) return "&cTúi đồ của bạn không đủ chỗ.";
        listings.remove(id);
        dirty = true;
        Util.give(p, l.item.clone());
        Util.msg(p, "&aĐã nhận lại &f" + l.label() + "&a.");
        return null;
    }

    /** Gọi định kỳ: đánh dấu hết hạn. */
    public void tick() {
        long now = System.currentTimeMillis();
        for (Listing l : listings.values()) {
            if (!l.expired && now >= l.expires) {
                l.expired = true;
                dirty = true;
                Player p = Bukkit.getPlayer(l.seller);
                if (p != null) {
                    Util.msg(p, "&eVật phẩm &f" + l.label() + " &ecủa bạn đã hết hạn. Vào &f/ah &e→ &fITEM CỦA BẠN &eđể nhận lại.");
                }
            }
        }
    }
}
