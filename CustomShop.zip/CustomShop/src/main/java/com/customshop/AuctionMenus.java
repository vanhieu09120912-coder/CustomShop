package com.customshop;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

public final class AuctionMenus {
    private AuctionMenus() {}

    // =====================================================================
    // /ah
    // =====================================================================
    public static class AhMenu extends Menu {
        private int page;
        private int pages = 1;
        private final Sort sort;
        private final String filter;
        private List<AuctionManager.Listing> view;

        public AhMenu(Player p, int page, Sort sort, String filter) {
            super(p);
            this.page = page;
            this.sort = sort;
            this.filter = filter;
        }

        @Override
        protected void build() {
            AuctionManager am = CustomShop.get().auctions();
            view = am.browse(filter, sort);
            pages = Math.max(1, (view.size() + 44) / 45);
            page = Math.max(0, Math.min(page, pages - 1));
            create(6, "&8/ah (" + (page + 1) + "/" + pages + ")");

            long now = System.currentTimeMillis();
            for (int i = 0; i < 45; i++) {
                int idx = page * 45 + i;
                if (idx >= view.size()) break;
                AuctionManager.Listing l = view.get(idx);
                inv.setItem(i, Util.addLore(l.item,
                        "",
                        "&7Giá: &a" + Util.money(l.price),
                        "&7Người bán: &f" + l.sellerName,
                        "&7Hết hạn sau: &f" + Util.duration(l.expires - now),
                        "",
                        "&eBấm để mua"));
            }
            fill(45, 53, filler());
            if (page > 0) inv.setItem(45, Util.item(Material.ARROW, "&eTrang trước"));
            inv.setItem(46, Util.item(Material.HOPPER, "&6Sắp xếp: &f" + sort.label, "&7Bấm để đổi"));
            inv.setItem(47, Util.item(Material.CLOCK, "&bLàm mới"));
            inv.setItem(48, Util.item(Material.OAK_SIGN, "&aTìm kiếm / Đăng bán",
                    "&7Tìm: &f/ah <tên vật phẩm>",
                    "&7Đăng bán: &f/ah sell <giá>",
                    filter == null ? "" : "&7Đang lọc: &f" + filter));
            inv.setItem(49, Util.item(Material.CHEST, "&a&lITEM CỦA BẠN", "&7Xem / thu hồi vật phẩm bạn đang bán"));
            inv.setItem(50, Util.item(Material.WRITABLE_BOOK, "&bĐơn hàng", "&7Mở /orders"));
            inv.setItem(51, Util.item(Material.EMERALD, "&aShop", "&7Mở /shop"));
            if (page < pages - 1) inv.setItem(53, Util.item(Material.ARROW, "&eTrang sau"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s < 45) {
                int idx = page * 45 + s;
                if (idx >= view.size()) return;
                AuctionManager.Listing l = view.get(idx);
                if (l.seller.equals(player.getUniqueId())) {
                    Util.msg(player, "&eĐây là đồ của bạn. Dùng nút &fITEM CỦA BẠN &eđể thu hồi.");
                    return;
                }
                new ConfirmMenu(player, l.id, this).openLater();
                return;
            }
            switch (s) {
                case 45 -> { if (page > 0) new AhMenu(player, page - 1, sort, filter).openLater(); }
                case 46 -> new AhMenu(player, 0, sort.next(), filter).openLater();
                case 47 -> new AhMenu(player, page, sort, filter).openLater();
                case 49 -> new MyItemsMenu(player, 0).openLater();
                case 50 -> new OrderMenus.OrdersMenu(player, 0, Sort.NEWEST).openLater();
                case 51 -> new ShopMenus.MainMenu(player).openLater();
                case 53 -> { if (page < pages - 1) new AhMenu(player, page + 1, sort, filter).openLater(); }
                default -> { }
            }
        }
    }

    // =====================================================================
    // Xác nhận mua
    // =====================================================================
    public static class ConfirmMenu extends Menu {
        private final long id;
        private final Menu back;

        public ConfirmMenu(Player p, long id, Menu back) {
            super(p);
            this.id = id;
            this.back = back;
        }

        @Override
        protected void build() {
            create(3, "&8Xác nhận mua");
            fill(0, 26, filler());
            AuctionManager.Listing l = CustomShop.get().auctions().get(id);
            if (l == null || l.expired) {
                inv.setItem(13, Util.item(Material.BARRIER, "&cVật phẩm không còn nữa", "&7Bấm để quay lại"));
                return;
            }
            inv.setItem(13, Util.addLore(l.item, "", "&7Người bán: &f" + l.sellerName));
            inv.setItem(11, Util.item(Material.LIME_CONCRETE, "&a&lXÁC NHẬN MUA", "&7Trả: &a" + Util.money(l.price)));
            inv.setItem(15, Util.item(Material.RED_CONCRETE, "&c&lHỦY", "&7Quay lại danh sách"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s == 11) {
                String err = CustomShop.get().auctions().buy(player, id);
                if (err != null) Util.msg(player, err);
                back.openLater();
            } else if (s == 15 || s == 13) {
                back.openLater();
            }
        }
    }

    // =====================================================================
    // ITEM CỦA BẠN
    // =====================================================================
    public static class MyItemsMenu extends Menu {
        private int page;
        private int pages = 1;
        private List<AuctionManager.Listing> list;

        public MyItemsMenu(Player p, int page) {
            super(p);
            this.page = page;
        }

        @Override
        protected void build() {
            list = CustomShop.get().auctions().of(player.getUniqueId());
            pages = Math.max(1, (list.size() + 44) / 45);
            page = Math.max(0, Math.min(page, pages - 1));
            create(6, "&8Item của bạn (" + (page + 1) + "/" + pages + ")");
            long now = System.currentTimeMillis();
            for (int i = 0; i < 45; i++) {
                int idx = page * 45 + i;
                if (idx >= list.size()) break;
                AuctionManager.Listing l = list.get(idx);
                inv.setItem(i, Util.addLore(l.item,
                        "",
                        "&7Giá: &a" + Util.money(l.price),
                        l.expired ? "&c&lĐÃ HẾT HẠN" : "&7Hết hạn sau: &f" + Util.duration(l.expires - now),
                        "",
                        "&eBấm để thu hồi vật phẩm"));
            }
            fill(45, 53, filler());
            if (page > 0) inv.setItem(45, Util.item(Material.ARROW, "&eTrang trước"));
            inv.setItem(49, Util.item(Material.BARRIER, "&cQuay lại /ah"));
            if (page < pages - 1) inv.setItem(53, Util.item(Material.ARROW, "&eTrang sau"));
        }

        @Override
        public void click(InventoryClickEvent e) {
            int s = e.getSlot();
            if (s < 45) {
                int idx = page * 45 + s;
                if (idx >= list.size()) return;
                String err = CustomShop.get().auctions().retrieve(player, list.get(idx).id);
                if (err != null) Util.msg(player, err);
                new MyItemsMenu(player, page).openLater();
                return;
            }
            if (s == 45 && page > 0) new MyItemsMenu(player, page - 1).openLater();
            else if (s == 49) new AhMenu(player, 0, Sort.NEWEST, null).openLater();
            else if (s == 53 && page < pages - 1) new MyItemsMenu(player, page + 1).openLater();
        }
    }
}
