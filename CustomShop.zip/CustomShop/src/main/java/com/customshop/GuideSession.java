package com.customshop;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Menu 3D lơ lửng trước mặt một người chơi (chỉ người đó thấy).
 * Gồm khối nền, chữ, vật phẩm là các Display entity. Nút đang được nhìn tới tính bằng tia từ mắt người chơi
 * cắt với mặt phẳng của menu, nên không cần entity có hitbox.
 */
public class GuideSession {
    private static final int MAX_LINES = 8;
    private static final float ICON_BASE = 0.55f;
    private static final float ICON_ACTIVE = 0.68f;
    private static final float ICON_HOVER = 0.85f;

    private final GuideManager manager;
    private final CustomShop plugin;
    private final Player viewer;
    private final World world;
    private final List<Entity> entities = new ArrayList<>();

    // Hệ tọa độ của menu: gốc, hướng tiến (ngang), hướng sang phải, hệ số thu phóng
    private double ox, oy, oz, fx, fz, rx, rz, k = 1.0;

    private final TextDisplay[] leftLines = new TextDisplay[MAX_LINES];
    private final TextDisplay[] rightLines = new TextDisplay[MAX_LINES];
    private TextDisplay leftTitle, rightTitle;
    private ArmorStand figure;
    private boolean closed = false;
    private ItemDisplay[] btnItems;
    private TextDisplay[] btnLabels;

    // vùng bấm: mỗi phần tử {tâmX, tâmY, nửaRộng, nửaCao}; phần tử cuối là nút ĐÓNG
    private final List<double[]> hits = new ArrayList<>();
    private int selected = -1;
    private int page = 0;
    private long lastClick = 0;

    public GuideSession(GuideManager manager, Player viewer) {
        this.manager = manager;
        this.plugin = manager.plugin();
        this.viewer = viewer;
        this.world = viewer.getWorld();
    }

    public Player viewer() { return viewer; }

    // ---------------------------------------------------------------------
    // Dựng menu
    // ---------------------------------------------------------------------
    public void open() {
        Location eye = viewer.getEyeLocation();
        double yaw = Math.toRadians(eye.getYaw());
        fx = -Math.sin(yaw);
        fz = Math.cos(yaw);
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);

        double want = manager.distance();
        double d = clearDistance(eye, want);
        k = d / want;
        ox = eye.getX() + fx * d;
        oy = eye.getY() + 0.2;
        oz = eye.getZ() + fz * d;

        build();
        page = manager.defaultIndex();
        showPage();
        refreshButtons();
    }

    /** Lùi menu lại gần người chơi nếu có tường chắn phía trước. */
    private double clearDistance(Location eye, double want) {
        double min = want * 0.5;
        for (double t = 0.5; t <= want + 0.4; t += 0.25) {
            int x = (int) Math.floor(eye.getX() + fx * t);
            int z = (int) Math.floor(eye.getZ() + fz * t);
            int y = (int) Math.floor(eye.getY());
            if (world.getBlockAt(x, y, z).getType().isSolid() || world.getBlockAt(x, y + 1, z).getType().isSolid()) {
                return Math.max(min, Math.min(want, t - 0.4));
            }
        }
        return want;
    }

    private void build() {
        Material panel = manager.panelMaterial();
        Material titleBlock = manager.titleMaterial();
        Material accent = manager.accentMaterial();
        Material line = Material.LIGHT_GRAY_CONCRETE;

        // Thanh tiêu đề (nền khối Minecraft ghép từng ô)
        tiled(0, 1.7, 5.5, 0.4, titleBlock, 0.0);
        block(0, 1.5, 5.5, 0.04, accent, -0.01);
        text(0, 1.7, manager.title(), 0.62);
        text(2.35, 1.7, "&7ĐÓNG", 0.5);

        // Hai bảng thông tin
        for (int side = -1; side <= 1; side += 2) {
            double sx = side * 1.75;
            tiled(sx, 0.4, 2.3, 1.8, panel, 0.0);
            block(sx, 1.28, 2.3, 0.04, accent, -0.01);
            block(sx, 1.0, 2.0, 0.012, line, -0.01);
            TextDisplay head = text(sx, 1.14, "", 0.55);
            if (side < 0) leftTitle = head; else rightTitle = head;
            for (int i = 0; i < MAX_LINES; i++) {
                TextDisplay t = text(sx, 0.85 - i * 0.185, "", 0.5);
                if (side < 0) leftLines[i] = t; else rightLines[i] = t;
            }
        }

        buildCenter();

        // Hàng nút
        List<GuideManager.Button> bs = manager.buttons();
        int n = bs.size();
        btnItems = new ItemDisplay[n];
        btnLabels = new TextDisplay[n];
        double spacing = Math.min(0.95, 5.6 / Math.max(1, n));
        List<double[]> btnHits = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            double x = (i - (n - 1) / 2.0) * spacing;
            GuideManager.Button b = bs.get(i);
            btnItems[i] = item(x, -0.95, new ItemStack(b.icon), ICON_BASE);
            btnLabels[i] = text(x, -1.3, b.label, 0.45);
            btnHits.add(new double[]{x, -1.0, spacing * 0.48, 0.5});
        }
        text(0, -1.62, manager.hint(), 0.42);

        hits.clear();
        hits.addAll(btnHits);
        hits.add(new double[]{2.35, 1.7, 0.38, 0.22}); // nút ĐÓNG (chỉ số = n)
    }

    /** Giữa menu: nhân vật mang skin người chơi đứng trên bệ (hoặc chỉ đầu / để trống theo huongdan.yml). */
    private void buildCenter() {
        String mode = manager.centerMode();
        if (mode.equals("none")) return;

        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = head.getItemMeta();
        if (meta instanceof SkullMeta sm) {
            sm.setOwningPlayer(viewer);
            head.setItemMeta(meta);
        }
        if (mode.equals("head")) {
            item(0, 0.7, head, 0.9f);
            return;
        }

        // Bệ đứng: khối obsidian + viền đỏ bên dưới (dày thật nên dùng BlockDisplay cỡ lớn)
        pedestal(0, -0.62, 1.0, 0.03, manager.accentMaterial());
        pedestal(0, -0.56, 0.9, 0.1, Material.OBSIDIAN);

        float yaw = viewer.getEyeLocation().getYaw() + 180f; // quay mặt về phía người chơi
        Location feet = at(0, -0.5, 0.0);
        feet.setYaw(yaw);
        ArmorStand st = world.spawn(feet, ArmorStand.class, e -> {
            e.setVisibleByDefault(false);
            e.setPersistent(false);
            e.setGravity(false);
            e.setInvulnerable(true);
            e.setSilent(true);
            e.setBasePlate(false);
            e.setArms(true);
            e.setMarker(true);
            e.setInvisible(true);
        });
        figure = register(st);
        EntityEquipment eq = st.getEquipment();
        if (eq != null) eq.setHelmet(head);
        applyColors(SkinColors.DEFAULT);
        manager.loadSkinColors(viewer, cols -> {
            if (!closed) applyColors(cols);
        });
    }

    private static ItemStack dyed(Material m, int rgb) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta instanceof LeatherArmorMeta lm) {
            lm.setColor(Color.fromRGB(rgb));
            it.setItemMeta(meta);
        }
        return it;
    }

    /** Nhuộm áo / quần / giày của nhân vật theo màu skin. */
    private void applyColors(int[] c) {
        if (figure == null) return;
        EntityEquipment eq = figure.getEquipment();
        if (eq == null) return;
        eq.setChestplate(dyed(Material.LEATHER_CHESTPLATE, c[0]));
        eq.setLeggings(dyed(Material.LEATHER_LEGGINGS, c[1]));
        eq.setBoots(dyed(Material.LEATHER_BOOTS, c[2]));
    }

    // ---------------------------------------------------------------------
    // Tạo entity
    // ---------------------------------------------------------------------
    private Location at(double x, double y, double dz) {
        return new Location(world, ox + rx * x * k + fx * dz, oy + y * k, oz + rz * x * k + fz * dz);
    }

    private void common(Display d) {
        d.setBillboard(Display.Billboard.VERTICAL);
        d.setBrightness(new Display.Brightness(15, 15));
        d.setPersistent(false);
        d.setVisibleByDefault(false);
    }

    private <T extends Entity> T register(T e) {
        entities.add(e);
        viewer.showEntity(plugin, e);
        return e;
    }

    private static Transformation scaleOnly(float sx, float sy, float sz) {
        return new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(sx, sy, sz), new AxisAngle4f());
    }

    private void block(double x, double y, double w, double h, Material m, double dz) {
        float sw = (float) (w * k);
        float sh = (float) (h * k);
        BlockDisplay b = world.spawn(at(x, y, dz), BlockDisplay.class, e -> {
            common(e);
            e.setBlock(m.createBlockData());
            e.setTransformation(new Transformation(new Vector3f(-sw / 2f, -sh / 2f, -0.01f), new AxisAngle4f(),
                    new Vector3f(sw, sh, 0.02f), new AxisAngle4f()));
        });
        register(b);
    }

    /** Lát nhiều khối nhỏ để texture không bị kéo giãn thành mảng lớn. */
    private void tiled(double x, double y, double w, double h, Material m, double dz) {
        int nx = Math.max(1, (int) Math.round(w / manager.tile()));
        int ny = Math.max(1, (int) Math.round(h / manager.tile()));
        double tw = w / nx;
        double th = h / ny;
        for (int i = 0; i < nx; i++) {
            for (int j = 0; j < ny; j++) {
                block(x - w / 2 + tw * (i + 0.5), y - h / 2 + th * (j + 0.5), tw, th, m, dz);
            }
        }
    }

    /** Khối dày (đối xứng nên không bị ảnh hưởng khi xoay theo camera). */
    private void pedestal(double x, double y, double size, double height, Material m) {
        float sw = (float) (size * k);
        float sh = (float) (height * k);
        BlockDisplay b = world.spawn(at(x, y, 0.0), BlockDisplay.class, e -> {
            common(e);
            e.setBlock(m.createBlockData());
            e.setTransformation(new Transformation(new Vector3f(-sw / 2f, -sh / 2f, -sw / 2f), new AxisAngle4f(),
                    new Vector3f(sw, sh, sw), new AxisAngle4f()));
        });
        register(b);
    }

    private TextDisplay text(double x, double y, String s, double scale) {
        float sc = (float) (scale * manager.textScale() * k * 2.0);
        TextDisplay t = world.spawn(at(x, y, -0.04), TextDisplay.class, e -> {
            common(e);
            e.setText(Util.col(s));
            e.setAlignment(TextDisplay.TextAlignment.CENTER);
            e.setLineWidth(2000);
            e.setDefaultBackground(false);
            e.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            e.setShadowed(true);
            e.setSeeThrough(false);
            e.setTransformation(scaleOnly(sc, sc, sc));
        });
        return register(t);
    }

    private ItemDisplay item(double x, double y, ItemStack stack, float scale) {
        float sc = scale * (float) k;
        ItemDisplay it = world.spawn(at(x, y, -0.06), ItemDisplay.class, e -> {
            common(e);
            e.setItemStack(stack);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            e.setTransformation(scaleOnly(sc, sc, sc));
        });
        return register(it);
    }

    // ---------------------------------------------------------------------
    // Nội dung & trạng thái
    // ---------------------------------------------------------------------
    private String fill(String s) {
        return s.replace("{player}", viewer.getName())
                .replace("{balance}", Util.full(plugin.balance(viewer)))
                .replace("{online}", String.valueOf(Bukkit.getOnlinePlayers().size()))
                .replace("{world}", viewer.getWorld().getName());
    }

    private void fillPanel(TextDisplay title, TextDisplay[] lines, String t, List<String> body) {
        title.setText(Util.col(fill(t)));
        for (int i = 0; i < MAX_LINES; i++) {
            lines[i].setText(i < body.size() ? Util.col(fill(body.get(i))) : "");
        }
    }

    private void showPage() {
        List<GuideManager.Button> bs = manager.buttons();
        if (page < 0 || page >= bs.size()) return;
        GuideManager.Button b = bs.get(page);
        fillPanel(leftTitle, leftLines, b.leftTitle, b.left);
        fillPanel(rightTitle, rightLines, b.rightTitle, b.right);
    }

    private void setScale(Display d, float s) {
        float sc = s * (float) k;
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(4);
        d.setTransformation(scaleOnly(sc, sc, sc));
    }

    private void refreshButtons() {
        List<GuideManager.Button> bs = manager.buttons();
        for (int i = 0; i < bs.size(); i++) refreshButton(i, bs.get(i));
    }

    private void refreshButton(int i, GuideManager.Button b) {
        boolean hover = i == selected;
        boolean active = b.isPage() && i == page;
        setScale(btnItems[i], hover ? ICON_HOVER : (active ? ICON_ACTIVE : ICON_BASE));
        String plain = ChatColor.stripColor(Util.col(b.label));
        String label = hover ? "&e&l" + plain : (active ? "&b&n" + plain : b.label);
        btnLabels[i].setText(Util.col(label));
    }

    // ---------------------------------------------------------------------
    // Vòng lặp: trả về false nếu cần đóng menu
    // ---------------------------------------------------------------------
    public boolean tick() {
        if (!viewer.isOnline() || viewer.isDead() || viewer.getWorld() != world) return false;
        Location loc = viewer.getLocation();
        double dx = loc.getX() - ox;
        double dy = loc.getY() - oy;
        double dz = loc.getZ() - oz;
        double max = manager.maxDistance();
        if (dx * dx + dy * dy + dz * dz > max * max) return false;

        int sel = pick();
        if (sel != selected) {
            int old = selected;
            selected = sel;
            List<GuideManager.Button> bs = manager.buttons();
            if (old >= 0 && old < bs.size()) refreshButton(old, bs.get(old));
            if (sel >= 0 && sel < bs.size()) refreshButton(sel, bs.get(sel));
            if (sel >= 0) Gui.hover(viewer);
        }
        return true;
    }

    /** Nút đang nằm dưới tâm ngắm: -1 = không có; chỉ số = số nút là nút ĐÓNG. */
    private int pick() {
        Location eye = viewer.getEyeLocation();
        Vector dir = eye.getDirection();
        double dn = dir.getX() * fx + dir.getZ() * fz;
        if (dn < 0.05) return -1;
        double t = ((ox - eye.getX()) * fx + (oz - eye.getZ()) * fz) / dn;
        if (t <= 0 || t > 12) return -1;
        double hx = eye.getX() + dir.getX() * t;
        double hy = eye.getY() + dir.getY() * t;
        double hz = eye.getZ() + dir.getZ() * t;
        double lx = ((hx - ox) * rx + (hz - oz) * rz) / k;
        double ly = (hy - oy) / k;
        for (int i = 0; i < hits.size(); i++) {
            double[] h = hits.get(i);
            if (Math.abs(lx - h[0]) <= h[2] && Math.abs(ly - h[1]) <= h[3]) return i;
        }
        return -1;
    }

    /** Người chơi bấm chuột. */
    public void click() {
        long now = System.currentTimeMillis();
        if (now - lastClick < 180) return;
        lastClick = now;
        if (selected < 0) return;
        List<GuideManager.Button> bs = manager.buttons();
        if (selected >= bs.size()) {
            manager.close(viewer);
            return;
        }
        GuideManager.Button b = bs.get(selected);
        if (b.isPage()) {
            int old = page;
            page = selected;
            showPage();
            if (old >= 0 && old < bs.size()) refreshButton(old, bs.get(old));
            refreshButton(selected, b);
            Gui.click(viewer);
        } else {
            String cmd = b.command.startsWith("/") ? b.command.substring(1) : b.command;
            manager.close(viewer);
            Bukkit.getScheduler().runTask(plugin, () -> viewer.performCommand(cmd));
        }
    }

    public void remove() {
        closed = true;
        for (Entity e : entities) {
            try {
                e.remove();
            } catch (Throwable ignored) {
                // entity đã bị xóa
            }
        }
        entities.clear();
    }
}
